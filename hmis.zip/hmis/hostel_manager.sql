-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2021 at 01:56 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `hostel_admin`
--

CREATE TABLE `hostel_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pin` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_admin`
--

INSERT INTO `hostel_admin` (`id`, `name`, `username`, `password`, `role`, `email`, `pin`) VALUES
(3, 'Taiwo Sarafa Aderemi', 'aderemi644', '$2y$10$388LZ0WoNXL67aH6gidIU.6/RdFeYl2ypBkJJ3ZvFWA7yw9NQfo22', 'admin', 'aderemi664@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hostel_application`
--

CREATE TABLE `hostel_application` (
  `id` int(11) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `hostel_id` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `room_no` int(11) DEFAULT NULL,
  `date_applied` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_application`
--

INSERT INTO `hostel_application` (`id`, `userid`, `hostel_id`, `status`, `room_no`, `date_applied`) VALUES
(3, 'CS2018020583', '4929', 1, 13, '2021-08-19 11:44:26'),
(4, 'CS20180205984', '4929', 0, 15, '2021-08-19 03:39:58'),
(5, 'CS201801012200', '4929', 1, 11, '2021-08-19 11:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_fee`
--

CREATE TABLE `hostel_fee` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `payment` varchar(20) NOT NULL,
  `status` char(20) NOT NULL,
  `others` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_fee`
--

INSERT INTO `hostel_fee` (`id`, `userid`, `payment`, `status`, `others`) VALUES
(1, 'CS2018020583', '15000', '1', '0'),
(2, 'CS20180205983', '0', '0', '0'),
(3, 'CS20180205982', '0', '0', '0'),
(4, 'CS20180205984', '15000', '1', '0'),
(5, 'CS201801012200', '15000', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_managers`
--

CREATE TABLE `hostel_managers` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` char(50) NOT NULL,
  `hostel` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_managers`
--

INSERT INTO `hostel_managers` (`id`, `userid`, `name`, `username`, `password`, `role`, `hostel`, `date_created`) VALUES
(1, 2299, 'Akinlabi Taiwo', 'manager001', '$2y$10$PYiI18tepHNVV73RNgT1SOlO5aRBf1W7GR0iqlyu9kSGqhjScPMze', 'Manager', 4929, '2021-08-18 13:21:55'),
(2, 4723, 'Babalola Babatola', 'manager002', '$2y$10$EsLpmPjKh7wjqWs5DJfdaO9MvdI9eYc0PVh87z0.XAmqP6Hb7A7uy', 'Manager', 4929, '2021-08-19 11:24:01');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_names`
--

CREATE TABLE `hostel_names` (
  `id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `hostel_name` varchar(100) NOT NULL,
  `block_name` varchar(50) NOT NULL,
  `total_rooms` int(11) NOT NULL,
  `available_rooms` int(11) NOT NULL,
  `capacity_per_room` int(11) NOT NULL,
  `capacity` bigint(20) NOT NULL,
  `hostel_category` char(50) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_names`
--

INSERT INTO `hostel_names` (`id`, `hostel_id`, `hostel_name`, `block_name`, `total_rooms`, `available_rooms`, `capacity_per_room`, `capacity`, `hostel_category`, `date_created`) VALUES
(1, 4929, 'Adekolawole', 'A23', 23, 0, 4, 92, 'Male', '2021-08-18 13:08:17'),
(2, 5243, 'Adelabu Deputy', 'A24', 43, 0, 3, 129, 'Female', '2021-08-19 11:29:49');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_rooms`
--

CREATE TABLE `hostel_rooms` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `room_number` varchar(20) NOT NULL,
  `capacity` int(11) NOT NULL,
  `num_occupy` int(11) NOT NULL,
  `status` char(20) NOT NULL,
  `conditions` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_rooms`
--

INSERT INTO `hostel_rooms` (`id`, `room_id`, `hostel_id`, `room_number`, `capacity`, `num_occupy`, `status`, `conditions`) VALUES
(1, 9260, 4929, '1', 4, 0, '2', 1),
(2, 4514, 4929, '2', 4, 0, '2', 1),
(3, 9177, 4929, '3', 4, 0, '2', 1),
(4, 5572, 4929, '4', 4, 0, '2', 1),
(5, 9111, 4929, '5', 4, 0, '2', 1),
(6, 6748, 4929, '6', 4, 0, '2', 1),
(7, 1344, 4929, '7', 4, 0, '2', 1),
(8, 2904, 4929, '8', 4, 0, '2', 1),
(9, 1326, 4929, '9', 4, 0, '2', 1),
(10, 2967, 4929, '10', 4, 0, '2', 1),
(11, 1652, 4929, '11', 4, 4, '0', 1),
(12, 4687, 4929, '12', 4, 0, '2', 1),
(13, 3539, 4929, '13', 4, 1, '1', 1),
(14, 4415, 4929, '14', 4, 0, '2', 1),
(15, 9187, 4929, '15', 4, 0, '2', 1),
(16, 3155, 4929, '16', 4, 0, '2', 1),
(17, 2396, 4929, '17', 4, 0, '2', 1),
(18, 637, 4929, '18', 4, 0, '2', 1),
(19, 3018, 4929, '19', 4, 0, '2', 1),
(20, 9173, 4929, '20', 4, 0, '2', 1),
(21, 7809, 4929, '21', 4, 0, '2', 1),
(22, 5015, 4929, '22', 4, 0, '2', 1),
(23, 2599, 4929, '23', 4, 0, '2', 1),
(24, 8653, 5243, '1', 3, 0, '2', 1),
(25, 2829, 5243, '2', 3, 0, '2', 1),
(26, 4201, 5243, '3', 3, 0, '2', 1),
(27, 3415, 5243, '4', 3, 0, '2', 1),
(28, 9672, 5243, '5', 3, 0, '2', 1),
(29, 6760, 5243, '6', 3, 0, '2', 1),
(30, 1979, 5243, '7', 3, 0, '2', 1),
(31, 1246, 5243, '8', 3, 0, '2', 1),
(32, 9247, 5243, '9', 3, 0, '2', 1),
(33, 3403, 5243, '10', 3, 0, '2', 1),
(34, 668, 5243, '11', 3, 0, '2', 1),
(35, 2442, 5243, '12', 3, 0, '2', 1),
(36, 9174, 5243, '13', 3, 0, '2', 1),
(37, 6641, 5243, '14', 3, 0, '2', 1),
(38, 7292, 5243, '15', 3, 0, '2', 1),
(39, 1984, 5243, '16', 3, 0, '2', 1),
(40, 7761, 5243, '17', 3, 0, '2', 1),
(41, 1303, 5243, '18', 3, 0, '2', 1),
(42, 4329, 5243, '19', 3, 0, '2', 1),
(43, 3528, 5243, '20', 3, 0, '2', 1),
(44, 5986, 5243, '21', 3, 0, '2', 1),
(45, 3057, 5243, '22', 3, 0, '2', 1),
(46, 7643, 5243, '23', 3, 0, '2', 1),
(47, 5687, 5243, '24', 3, 0, '2', 1),
(48, 4523, 5243, '25', 3, 0, '2', 1),
(49, 5578, 5243, '26', 3, 0, '2', 1),
(50, 342, 5243, '27', 3, 0, '2', 1),
(51, 1249, 5243, '28', 3, 0, '2', 1),
(52, 6402, 5243, '29', 3, 0, '2', 1),
(53, 2689, 5243, '30', 3, 0, '2', 1),
(54, 2056, 5243, '31', 3, 0, '2', 1),
(55, 4308, 5243, '32', 3, 0, '2', 1),
(56, 2953, 5243, '33', 3, 0, '2', 1),
(57, 2966, 5243, '34', 3, 0, '2', 1),
(58, 8783, 5243, '35', 3, 0, '2', 1),
(59, 4541, 5243, '36', 3, 0, '2', 1),
(60, 566, 5243, '37', 3, 0, '2', 1),
(61, 9796, 5243, '38', 3, 0, '2', 1),
(62, 2774, 5243, '39', 3, 0, '2', 1),
(63, 1323, 5243, '40', 3, 0, '2', 1),
(64, 3366, 5243, '41', 3, 0, '2', 1),
(65, 4197, 5243, '42', 3, 0, '2', 1),
(66, 5570, 5243, '43', 3, 0, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hostel_students`
--

CREATE TABLE `hostel_students` (
  `id` int(11) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `gender` char(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(70) NOT NULL,
  `level` char(50) NOT NULL,
  `year_of_study` int(11) NOT NULL,
  `passport` blob NOT NULL,
  `password` varchar(255) NOT NULL,
  `dates_signup` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hostel_students`
--

INSERT INTO `hostel_students` (`id`, `userid`, `firstname`, `lastname`, `department`, `gender`, `phone`, `email`, `level`, `year_of_study`, `passport`, `password`, `dates_signup`) VALUES
(1, 'CS2018020583', 'Sarafa', 'Taiwo', 'Cpmputer Science', 'Male', '0803344887', 'user543@gmail.com', '', 2017, 0x4353323031383032303538332e6a7067, '$2y$10$NCzVMpUHaxF/8SVpeFIjP.ZigSDrEgknKQ5K..1qilGB4/0o4j7Py', '2021-08-19 11:43:49'),
(2, 'CS20180205983', 'Taiwo Eniola', 'Adekinalbi', 'Statistics', 'Female', '08033009987', 'user5436@gmail.com', '', 2017, 0x435332303138303230353938332e6a7067, '$2y$10$2lPV47Ybhx14MVE1gcZokeC8cdyBowS3LPOe./h7KCPUzFJv8b80S', '2021-08-19 11:43:49'),
(3, 'CS20180205982', 'Taiwo Arinola', 'Akinlabi', 'Statistics', 'Female', '09088776655', 'userss543@gmail.com', '', 2017, 0x435332303138303230353938322e6a7067, '$2y$10$BZ8vIVhoYW.6qRXbBH0CZeShjAb2YBwccuLCRKNng.fo2apYdGcvm', '2021-08-19 11:43:49'),
(4, 'CS20180205984', 'Sarafa', 'Aderemi', 'Cpmputer Science', 'Male', '08077663322', 'taderemi93@gmail.com', '', 2017, 0x435332303138303230353938342e6a7067, '$2y$10$kDo3g1tNfu8PJWVcYZARJek/NREWSmuWLhq5SPrSgTFW3G0xdkBtW', '2021-08-19 03:38:46'),
(5, 'CS201801012200', 'Waleola', 'Adekola', 'Cpmputer Science', 'Male', '08077665544', 'user1234@gmail.com', '', 2019, 0x43533230313830313031323230302e6a7067, '$2y$10$5L2f4mectQUQN3cv/xbxc.yM2ZYrycgUUm.fu..kBSMzjFIRc1WVu', '2021-08-19 11:18:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hostel_admin`
--
ALTER TABLE `hostel_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_application`
--
ALTER TABLE `hostel_application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_fee`
--
ALTER TABLE `hostel_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_managers`
--
ALTER TABLE `hostel_managers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_names`
--
ALTER TABLE `hostel_names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_rooms`
--
ALTER TABLE `hostel_rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_students`
--
ALTER TABLE `hostel_students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hostel_admin`
--
ALTER TABLE `hostel_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hostel_application`
--
ALTER TABLE `hostel_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `hostel_fee`
--
ALTER TABLE `hostel_fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `hostel_managers`
--
ALTER TABLE `hostel_managers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hostel_names`
--
ALTER TABLE `hostel_names`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hostel_rooms`
--
ALTER TABLE `hostel_rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `hostel_students`
--
ALTER TABLE `hostel_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
