<?php
require_once 'inc/head.php';
?>
<body class="hero">
   <section id="hero">
    <div class="hero-container">
      <div class="row">
          <div class="col-lg-12">
            <a href="default"><h2 class=""><span>Hostel</span> Management System</h2></a>
            <p class="text-center">Hostel Managemnet system provide is system that privide the way and means of getting condusive, affordable, effective and a affordable accomcdation for the great Aluta Student of The Federal Polytechnic, Ede.</p>
            <div class="text-center">
                <a href="signin" class="btn-menu">Get Started</a>
                <a href="signin" class="btn-book">Book a Room</a>
            </div>
          </div>
      </div>
    </div>
    <div class="container aos-init aos-animate" data-aos="fade-up">
        <div class="row no-gutters">

          <div class="col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">Supervisor in Charge</span>
              <p><strong>Mr Samuel Fasoyiro</strong></p>
              <p><strong>School of Applied Science</strong></p>
              <p><strong>Department of Computer Science</strong></p>
            </div>
          </div>

          <div class="col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">Developed by</span>
              <p><strong>Abdulhammed Adbulljelil Oladaoi »</strong> CS20180100</p>
              <p><strong>Lawrence Opeyemi Peter »</strong> CS20180100</p>
              <p><strong>Abidoye Muideen Boluwatife »</strong> CS20180100</p>
            </div>
          </div>
        </div>
      </div>
  </section>
</body>
</html>
<?php require_once 'inc/foot.php'; ?>