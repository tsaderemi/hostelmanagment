<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="The Nigerians Number One Online Peer to Peer Payment Platform">
  <title>Profile - Hostel Management</title>

    <?php require_once 'inc/header.php' ?>
    <?php require_once 'inc/nav.php' ?>



    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
         <div class="col-md-12 top">
            <h3>Profile <i class="fa fa-th-large"></i> ID: <?php echo $userid; ?></h3>
          </div>
        <div class="row mt">
          <div class="col-lg-12">
            <div class="row content-panel">
              <div class="col-md-6 profile-text mt mb centered">
                <div class="right-divider hidden-sm hidden-xs">
                  <h6>HOSTEL FEE</h6>
                  <h4>&#8358; <?php echo number_format($feeRs["payment"],2); ?></h4>
                  
                   <h6>OTHERS</h6>
                  <h4>&#8358; <?php echo number_format($feeRs["others"],2); ?></h4>
                 
                  <h6>NOTIFICATION</h6>
                  <h4>
                    <?php
                      if($countAppRes->num_rows > 0){
                        $countAppRs = $countAppRes->fetch_assoc();
                        echo $countAppRs["totApp"];
                      }
                    ?>
                </h4>
                  
                </div>
              </div>
              <div class="col-md-6 centered">
                <div class="profile-pic">
                  <p><img src="../passport/<?php echo($rs["passport"]); ?>" class="img-circle"></p>
                </div>
                <h4><?php echo $name; ?></h4>
                <h6><?php echo $userid; ?></h6>
              </div>
              <!-- /col-md-4 -->
            </div>
            <!-- /row -->
          </div>
          <!-- /col-lg-12 -->
          <div class="col-lg-12 mt">
            <div class="content-panel">
              <div class="row">
                <div class="panel-heading">
                  <span><?php echo flash(); ?></span>
                  <ul class="nav nav-tabs nav-justified">
                    <li class="active">
                      <a data-toggle="tab" href="#overview">Overview</a>
                    </li>
                    <li>
                      <a data-toggle="tab" href="#edit">Update Profile</a>
                    </li>
                  </ul>
                </div>
                <!-- /panel-heading -->
                <div class="panel-body">
                  <div class="tab-content">
                    <div id="overview" class="tab-pane active">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="detailed">
                            <h4 style="border-bottom-color: #fff;">Personal Info</h4>
                            <table class="table table-striped">
                              <tr>
                                <th>User Id:</th>
                                <td><?php echo $userid; ?></td>
                              </tr>
                              <tr>
                                <th>Fuul Name:</th>
                                <td><?php echo $name; ?></td>
                              </tr>
                              <tr>
                                <th>Gender:</th>
                                <td><?php echo $rs["gender"]; ?></td>
                              </tr>
                              <tr>
                                <th>Email</th>
                                <td><?php echo $rs["email"]; ?></td>
                              </tr>
                              <tr>
                                <th>Phone</th>
                                <td><?php echo $rs["phone"]; ?></td>
                              </tr>
                              <tr>
                                <th>Department</th>
                                <td><?php echo $rs["department"]; ?></td>
                              </tr>
                            </table>
                          </div>
                          
                        </div>
                        <!-- /col-md-6 -->
                        <div class="col-md-6 detailed">
                          <h4 style="border-bottom-color: #fff;">Hostel Information</h4>
                            <table class="table table-striped">
                              <tr>
                                <th>User Id:</th>
                                <td><?php echo $userid; ?></td>
                              </tr>
                              <tr>
                                <th>Fuul Name:</th>
                                <td><?php echo $name; ?></td>
                              </tr>
                              <tr>
                                <th>Gender:</th>
                                <td><?php echo $rs["gender"]; ?></td>
                              </tr>
                              <tr>
                                <th>Phone</th>
                                <td><?php echo $rs["phone"]; ?></td>
                              </tr>
                              <tr>
                                <th>Department</th>
                                <td><?php echo $rs["department"]; ?></td>
                              </tr>
                            </table>
                          <!-- /detailed -->
                          
                          <!-- /row -->
                        </div>
                        <!-- /col-md-6 -->
                      </div>
                      <!-- /OVERVIEW -->
                    </div>
                    <!-- /tab-pane -->
                    <div id="edit" class="tab-pane">
                      <div class="row">
                        <div class="col-lg-6 detailed">
                          <h4 class="mb">Change Password</h4>
                          <form role="form" class="form-horizontal" style="padding: 0 30px;">
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Old Password</label>
                              <div class="col-lg-6">
                                <input type="text" placeholder=" " id="lives-in" class="form-control" required="">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-6 control-label">New Password</label>
                              <div class="col-lg-6">
                                <input type="text" placeholder=" " id="country" class="form-control" required="">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Confirm New Password</label>
                              <div class="col-lg-6">
                                <input type="text" placeholder=" " id="country" class="form-control" required="">
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="col-lg-offset-2 col-lg-10">
                                <button class="btn btn-theme" type="submit">Save</button>
                                <button class="btn btn-theme04" type="button">Cancel</button>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="col-lg-6 detailed">
                          <h4 class="mb">Personal Information</h4>
                          <form role="form" class="form-horizontal" style="padding: 0 30px;">
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Phone</label>
                              <div class="col-lg-6">
                                <input type="text" placeholder=" " id="c-name" class="form-control" required="">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Email</label>
                              <div class="col-lg-6">
                                <input type="text" placeholder=" " id="c-name" class="form-control" required="">
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="col-lg-offset-2 col-lg-10">
                                <button class="btn btn-theme" type="submit">Save</button>
                                <button class="btn btn-theme04" type="button">Cancel</button>
                              </div>
                            </div>
                          </form>
                        </div>
                        <!-- /col-lg-6 -->
                      </div>
                      <!-- /row -->
                    </div>
                    <!-- /tab-pane -->
                  </div>
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <?php require_once 'inc/foot.php' ?>