<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="The Nigerians Number One Online Peer to Peer Payment Platform">
  <title>Dashboard - Hostel Management</title>

   <?php require_once 'inc/header.php' ?>
    <?php require_once 'inc/nav.php' ?>
<style>
  .bold{
    font-weight: bold;
  }
  .italics{
    font-style: initial;
    font-size: 25px;
  }
  .label{
    padding: 6px 35px;
    font-size: 15px;
    font-family: times-newroman;
  }
</style>
<body onload="setTimeout(noticeBank,3000);">

<script>
  function noticeBank(){
    document.getElementById('bank').style.display = 'block';
  }
</script>
  <section id="main-content">
    <section class="wrapper">
      <div class="row">
        <div class="col-md-12 top">
          <h3>Hostel Fee <i class="fa fa-th-large"></i> ID: <?php echo $userid; ?></h3>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Hostel Fee</span>
              <span class="info-box-number">&#8358; <?php echo number_format($feeRs["payment"],2); ?></span>
            </div>
            <div class="info-box-content">
              <?php
                $amount = $feeRs["payment"];
                $status = $feeRs["status"];
                if($amount > 0){
                  if($status == 0){
                ?>
                  <a href="paystackpayment.php" class="label label-danger">Pay Now</a>
                <?php
                  }else{
                ?>
                  <a href="#" class="label label-success">Paid <i class="fa fa-check"></i></a>
                <?php
                  }
                }
              ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-flag-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Other Fee</span>
              <span class="info-box-number">&#8358; <?php echo number_format($feeRs["others"],2); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-files-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Application</span>
              <span class="info-box-number">
                <?php
                if($countAppRes->num_rows > 0){
                  $countAppRs = $countAppRes->fetch_assoc();
                  echo $countAppRs["totApp"];
                }
                ?>
              </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
      </div>
      <div class="row cards mt">

        <?php
        $checkApp = "SELECT 1 from hostel_application where userid = '$userid' ";
        $checkAppRes = $conn->query($checkApp)or
        die(mysqli_error($conn));
        if($checkAppRes->num_rows > 0){
        ?>
        <div class="col-md-12">
          <div class="card card-hover">
            <div class="box bg-red text-center">
              <h1 class="font-light text-white"><i class="fa fa-warning"></i></h1>
              <h6 class="text-white">An application for hostel has been sbmitted, kindly exercie patent it has not been approved.  If the hostel application has been approved, kindly do the necessery task to complete your hostel application</h6>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
         <!-- Column -->
        
        <!-- Column -->
      </div>
      <div class="row mt">
            <div class="col-md-12 activity">
              <div class="content-panel">
                <div class="border-head">
                  <h3>
                    Hostel Allocation History
                  </h3>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="tabless">
                      <thead>
                        <tr>
                          <th>#</th>                          
                          <th>User Id</th>
                          <th>Hostel Name</th>
                          <th>Room Number</th>
                          <th>Date Applied</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $sql = "SELECT * from hostel_application where userid = '$userid' ";
                          $result = $conn->query($sql)or
                          die(mysqli_error($conn));
                          $sn = "";
                          while ($rs = $result->fetch_assoc()){
                            $status = $rs["status"];
                            $hostelid = $rs["hostel_id"];
                        ?>
                          <tr>
                            <td><?php echo ++$sn; ?></td>                            
                            <td><?php echo $rs["userid"]; ?></td>
                            <td>
                               <?php
                                      $hblock  = "SELECT * from hostel_names where hostel_id = '$hostelid' ";
                                      $hblockRes = $conn->query($hblock)or
                                      die(mysqli_error($conn));
                                      if($hblockRes->num_rows > 0){
                                        $hblockRs = $hblockRes->fetch_assoc();

                                        echo $hblockRs["hostel_name"]." ".$hblockRs["block_name"];
                                      }
                                ?>
                            </td>
                            <td>Room <?php echo $rs["room_no"]; ?></td>
                            <td><?php echo $rs["date_applied"]; ?></td>
                            <td>
                              <?php
                              if($status == "0"){
                              ?>
                                <span class="btn btn-warning btn-sm" href="javascript:void();">Pending <i class="fa fa-hourglass-half"></i></span>
                              <?php
                              }else if($status == "1"){
                              ?>
                                <span class="btn btn-success btn-sm" href="javascript:void();">Approved <i class="fa fa-check"></i></span>
                              <?php
                              }
                              ?>
                            </td>                           
                          </tr>
                        <?php
                          }
                        ?>
                      </tbody>
                    </table>
                    <?php
                    /*
                    $start = "";
                    $end = 1000;

                    for($start = 1; $start <= $end; $start++){
                    ?>
                      <p class="<?php if(($start % 3) == 0){echo('italic');}else if(($start % 10) == 0){echo('bold');} ?>"><?php echo $start ?></p>
                    <?php
                    }
                    */
                    ?>
                  </div>
                </div>
              </div>
            </div>
    </section>
  </section>
  <!--main content end-->
  <!--footer start-->
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <?php require_once 'inc/foot.php' ?>