          <div class="col-md-12">
            <div class="content-panel">
              <div class="row">
                <div class="col-md-4 centered">
                  <div class="profile-pic">
                    <p><img src="../passport/<?php echo($rs["passport"]); ?>" class="img-circle"></p>
                    <h3><?php echo $name; ?></h3>
                      <h6>ID: <?php echo $userid; ?></h6>
                  </div>
                </div>
                <div class="col-md-4 profile-text">
                  <h3>Teachers Comment</h3>
                  <h6>Main Administrator</h6>
                  <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC.</p>
                  <br>
                  <!--<p><button class="btn btn-theme"><i class="fa fa-envelope"></i> Send Message</button></p>-->
                </div>
                <div class="col-md-4 profile-text mb centered left-divider">
                  <div class="">
                    <h6>Hostel Fee</h6>
                    <h4>&#8358; <?php echo number_format($feeRs["payment"],2); ?></h4>
                    <h6>Total Payment</h6>
                    <h4>&#8358; <?php echo number_format($totAmount); ?></h4>
                    <h6>Amount Left</h6>
                    <h4>&#8358; <?php if($class <= 5){echo number_format($kgnur-$totAmount);}else{echo number_format($basic-$totAmount);} ?></h4>
                    
                  </div>
                </div>
              </div>
              <!-- /col-md-4 -->
            </div>
            <!-- /row -->
          </div>