<!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong style="cursor: pointer;">FPE Hostel Management Information System</strong>. All Rights Reserved
        </p>
        <div class="social">
          <!--<a href="https://chat.whatsapp.com/" class="whatsapp"><i class="fa fa-whatsapp"></i></a>&nbsp;&nbsp;
          <a href="https://t.me/joinchat/NDyjqRinf45gZd1jpR2-eQ"><i class="fa fa-telegram"></i></a>-->
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../dashboard/lib/DataTables/datatables.min.js"></script>
  <script src="../dashboard/lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../dashboard/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../dashboard/lib/jquery.scrollTo.min.js"></script>
  <script src="../dashboard/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../dashboard/lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../dashboard/lib/common-scripts.js"></script>
  <script type="../dashboard/text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
  <script type="../dashboard/text/javascript" src="lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="../dashboard/lib/sparkline-chart.js"></script>
  <script src="../dashboard/lib/zabuto_calendar.js"></script>
  <script src="../dashboard/lib/chart-master/Chart.js"></script>
  <script src="../dashboard/lib/chartjs-conf.js"></script>
  <!--
  <script type="text/javascript">
    $(document).ready(function() {
      var unique_id = $.gritter.add({
        // (string | mandatory) the heading of the notification
        title: 'Welcome to Dashio!',
        // (string | mandatory) the text inside the notification
        text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo.',
        // (string | optional) the image to display on the left
        image: 'img/ui-sam.jpg',
        // (bool | optional) if you want it to fade out on its own or just sit there
        sticky: false,
        // (int | optional) the time you want it to be alive for before fading out
        time: 8000,
        // (string | optional) the class name you want to apply to that specific message
        class_name: 'my-sticky-class'
      });

      return false;
    });
  </script>
-->
<!--
<script>
  $(document).ready(function() {
    $("#amount").keyup(function() {
      var charge = (Number($("#amount").val()) * 0.02);
      $("#total").val("N" + (Number($("#amount").val()) + charge ));
      $("#charge").val(charge)
  });

});
</script>
-->
<script src="./Paystackpayment_files/jquery.min.js.download"></script>


<script>
                $(document).ready(function() {

                    $("#id_network").change(function() {
                        var name = $(this).children("option:selected").val();

                        $("#id_amount").change(function() {
                            var amount = $(this).children("option:selected").val();


                            if (name == "1") {

                                $("#amount").text('#' + (Number(amount) * (Number(80) / 100)));


                            }


                            if (name == "2") {
                                $("#amount").text('#' + (Number(amount) * (Number(77) / 100)));


                            }

                            if (name == "3") {
                               $("#amount").text('#' + (Number(amount) * (Number() / 100)));



                            }
                            if (name == "4") {
                               $("#amount").text('#' + (Number(amount) * (Number(75) / 100)));




                            }


                        });
                    });

                });
            </script>
  <script type="application/javascript">
    $(document).ready(function() {
      $('#tables').DataTable();
      $('#tabless').DataTable();
      $('#table1').DataTable();
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });


    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
  <!-- Pie Chart -->
  <script>
    var Pie = function(data,config,ctx){
    var segmentTotal = 0;
    
    //In case we have a canvas that is not a square. Minus 5 pixels as padding round the edge.
    var pieRadius = Min([height/2,width/2]) - 5;
    
    for (var i=0; i<data.length; i++){
      segmentTotal += data[i].value;
    }
    
    
    animationLoop(config,null,drawPieSegments,ctx);
        
    function drawPieSegments (animationDecimal){
      var cumulativeAngle = -Math.PI/2,
      scaleAnimation = 1,
      rotateAnimation = 1;
      if (config.animation) {
        if (config.animateScale) {
          scaleAnimation = animationDecimal;
        }
        if (config.animateRotate){
          rotateAnimation = animationDecimal;
        }
      }
      for (var i=0; i<data.length; i++){
        var segmentAngle = rotateAnimation * ((data[i].value/segmentTotal) * (Math.PI*2));
        ctx.beginPath();
        ctx.arc(width/2,height/2,scaleAnimation * pieRadius,cumulativeAngle,cumulativeAngle + segmentAngle);
        ctx.lineTo(width/2,height/2);
        ctx.closePath();
        ctx.fillStyle = data[i].color;
        ctx.fill();
        
        if(config.segmentShowStroke){
          ctx.lineWidth = config.segmentStrokeWidth;
          ctx.strokeStyle = config.segmentStrokeColor;
          ctx.stroke();
        }
        cumulativeAngle += segmentAngle;
      }     
    }   
  }

  var pieData = [
        {
            value: 30,
            color:"#1abc9c"
        },
        {
            value : 70,
            color : "#16a085"
        }

    ];
    new Chart(document.getElementById("pie").getContext("2d")).Pie(pieData);
  </script>
</body>
<script>
      if(window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
    </script>
</html>