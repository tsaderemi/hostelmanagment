<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile"><img src="../passport/<?php echo($rs["passport"]); ?>" class="img-circle" width="100" height="100"></a></p>
          <h5 class="centered"><?php echo $name; ?></h5>
          <h6 class="centered text-silver"><?php echo $userid; ?></h6>
          <li class="mt">
            <a class="" href="dashboard">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="">
            <a href="booking">
              <i class="fa fa-tv"></i>
              <span>Booking</span>
            </a>
          </li>
          <li class="">
            <a href="fee">
              <i class="fa fa-credit-card"></i>
              <span>Hostel Fee</span>
            </a>
          </li>
          </li>
          <li class="sub-menu dcjq-parent-li">
            <a href="javascript:;" class="dcjq-parent">
              <i class="fa fa-download"></i>
              <span>Download/Printing</span>
              <span class="dcjq-icon"></span></a>
            <ul class="sub" style="display: none;">
              <li><a target="_blank" href="../documents/hostelfee.php?reg=<?php echo($userid); ?>">Hostel Fee Receipt</a></li>
              <li><a href="transfer">Hostel Room</a></li>
              <li><a href="panels.html">Clearance</a></li>
            </ul>
          </li>
          <li class="">
            <a class="" href="profile">
              <i class="fa fa-user"></i>
              <span>My Profile</span>
              </a>
          </li>
          <li class="">
            <a class="" href="logout">
              <i class="fa fa-sign-out"></i>
              <span>Logout</span>
              </a>
          </li>
        <!-- sidebar menu end-->
      </div>
    </aside>