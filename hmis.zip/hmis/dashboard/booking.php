<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="The Nigerians Number One Online Peer to Peer Payment Platform">
  <title>Booking - Hostel Management</title>

    <?php require_once 'inc/header.php' ?>
    <?php require_once 'inc/nav.php' ?>

    <?php
    if(isset($_POST["ok-book"])){
      $userid = mysqli_real_escape_string($conn,$_POST["userid"]);
      $hostelid = mysqli_real_escape_string($conn,$_POST["hostelid"]);
      $roomno = mysqli_real_escape_string($conn,$_POST["roomno"]);


      $sql = "INSERT into hostel_application (userid,hostel_id,status,room_no) values ('$userid','$hostelid',0,'$roomno') ";
      $result = $conn->query($sql)or
      die(mysqli_error($conn));

      if($result === TRUE){
        set_flash("Hostel booking applied successfully","success");
        $sql = "UPDATE hostel_fee set payment = 15000 where userid = '$userid' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        
      }else{
        set_flash("There was error in hostel application","danger");
      }
    }
    ?>

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
         <div class="col-md-12 top">
            <h3>Booking <i class="fa fa-th-large"></i> ID: <?php echo $userid; ?></h3>
          </div>
        <div class="row mt">
          <div class="col-lg-12 mt">
            <div class="content-panel">
              <div class="row">
                <div class="panel-heading">
                  <span><?php echo flash(); ?></span>
                </div>
                
                        <div class="col-lg-12 detailed">
                          <h4 class="mb">Book A Room</h4>
                          <?php
                          $checkApp = "SELECT 1 from hostel_application where userid = '$userid' ";
                          $checkAppRes = $conn->query($checkApp)or
                          die(mysqli_error($conn));
                          if($checkAppRes->num_rows > 0){
                          ?>
                          <div class="alert alert-info">
                            An application for hostel has been sbmitted, kindly exercie patent it has not been approved.  If the hostel application has been approved, kindly do the necessery task to complete your hostel application
                          </div>
                          <?php
                          }else{
                          ?>
                          <form role="form" class="form-horizontal" style="padding: 0 30px;" action="" method="post">
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Hostel Name</label>
                              <div class="col-lg-6">
                                <select class="form-control" name="hostelid" id="disHostels" required="" onchange="">
                                  <option></option>
                                  <?php echo booking_hostel($conn,$gender); ?>
                                </select>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Select Room of Choice</label>
                              <div class="col-lg-6">
                                <select class="form-control" name="roomno" id="displayRooms" required="">
                                </select>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-lg-6 control-label">Available Room Space</label>
                              <div class="col-lg-6">
                                <input type="text" name="" readonly="" class="form-control" id="displayRoomInfo">
                              </div>
                            </div>
                            <div class="form-group">
                              <div class="col-lg-offset-2 col-lg-10">
                                <input type="hidden" name="userid" value="<?php echo($userid) ?>">
                                <button class="btn btn-theme" type="submit" name="ok-book"><i class="fa fa-check"></i> Submit Application</button>
                                <button class="btn btn-theme04" type="reset">Cancel <i class="fa fa-times"></i></button>
                              </div>
                            </div>
                          </form>
                          <?php
                            }
                          ?>
                        </div>
                      </div>
                      <!-- /row -->
                    </div>
          </div>
          <!-- /row -->
        </div>
        <div class="row mt">
            <div class="col-md-12 activity">
              <div class="content-panel">
                <div class="border-head">
                  <h3>
                    Room Application History
                  </h3>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="tabless">
                      <thead>
                        <tr>
                          <th>#</th>                          
                          <th>User Id</th>
                          <th>Hostel Name</th>
                          <th>Room Number</th>
                          <th>Date Applied</th>
                          <th>Status</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $sql = "SELECT * from hostel_application where userid = '$userid' ";
                          $result = $conn->query($sql)or
                          die(mysqli_error($conn));
                          $sn = "";
                          while ($rs = $result->fetch_assoc()){
                            $status = $rs["status"];
                            $hostelid = $rs["hostel_id"];
                        ?>
                          <tr>
                            <td><?php echo ++$sn; ?></td>
                            <td><?php echo $rs["userid"]; ?></td>
                            <td>
                               <?php
                                      $hblock  = "SELECT * from hostel_names where hostel_id = '$hostelid' ";
                                      $hblockRes = $conn->query($hblock)or
                                      die(mysqli_error($conn));
                                      if($hblockRes->num_rows > 0){
                                        $hblockRs = $hblockRes->fetch_assoc();

                                        echo $hblockRs["hostel_name"]." ".$hblockRs["block_name"];
                                      }
                                ?>
                            </td>
                            <td>Room <?php echo $rs["room_no"]; ?></td>
                            <td><?php echo $rs["date_applied"]; ?></td>
                            <td>
                              <?php
                              if($status == "0"){
                              ?>
                                <span class="btn btn-warning btn-sm" href="javascript:void();">Pending <i class="fa fa-hourglass-half"></i></span>
                              <?php
                              }else if($status == "1"){
                              ?>
                                <span class="btn btn-success btn-sm" href="javascript:void();">Approved <i class="fa fa-check"></i></span>
                              <?php
                              }
                              ?>
                            </td>                           
                          </tr>
                        <?php
                          }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <?php require_once 'inc/foot.php' ?>
    <script type="text/javascript">
    $(document).ready(function(){

      $("#disHostels").on("change", function(){
          var hostelId = $(this).val();
          if(hostelId == 'Select Hostel..'){
            $("#displayRooms").html('');
          }else{
            $.ajax({
              url: "ajax.php?getRooms",
              type: "POST",
              data: {
                hostelid: hostelId
              },
              success: function(results){
                $("#displayRooms").html(results);
              },
            });
          }
        });

      $("#displayRooms").on("change", function(){
        var roomId = $(this).val();
        if(roomId == ''){
          $("#displayRoomInfo").val('');
        }else{
            $.ajax({
              url: "ajax.php?getRoomInfo",
              type: "POST",
              data: {
                roomid: roomId
              },
              success: function(results){
                $("#displayRoomInfo").val(results);
              },
            });
          }
      })
      
    });
  </script>