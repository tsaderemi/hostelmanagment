<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="The Nigerians Number One Online Peer to Peer Payment Platform">
  <title>Payment - Hostel Management</title>

   <?php require_once 'inc/header.php' ?>
    <?php require_once 'inc/nav.php' ?>
<style>
  .bold{
    font-weight: bold;
  }
  .italics{
    font-style: initial;
    font-size: 25px;
  }
  .label{
    padding: 6px 35px;
    font-size: 15px;
    font-family: times-newroman;
  }
</style>
<body onload="setTimeout(noticeBank,3000);">

<script>
  function noticeBank(){
    document.getElementById('bank').style.display = 'block';
  }
</script>
  <section id="main-content">
     <section class="wrapper">
        <div class="row">
          <div class="col-md-12 top">
            <h3>Hostel Fee Payment <i class="fa fa-th-large"></i> ID: <?php echo $userid; ?></h3>
          </div>
        </div>
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Paystack Payment Method</h4>
              <form class="form-horizontal style-form" method="post" action="initialize">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Amount (&#8358;)</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" required="" id="amount" readonly="" value="&#8358; <?php echo number_format($feeRs["payment"],2); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Matric No</label>
                  <div class="col-sm-10">
                    <input type="text" readonly="" class="form-control" required="" id="userid" value="<?php echo($userid); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Email</label>
                  <div class="col-sm-10">
                    <input type="text" readonly="" class="form-control" required="" id="email" value="<?php echo($email); ?>">

                  </div>
                </div>
                
                <div class="form-group">
                  <div class="col-lg-offset-2 col-lg-10">
                    <input type="hidden" name="totAmount" id="totAmount" value="<?php echo($feeRs["payment"]."00"); ?>">
                    <button class="btn btn-theme" type="button" onclick="payWithPaystack()" style="width: 200px; padding: 10px;"> Pay Hostel Fee <i class="fa fa-check"></i></button> 
                  </div>
                </div>
                
                  <center>
                    <img src="../images/paystack.png" style="width: 350px; height: 150px;">
                  </center>
                
              </form>
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
        <!-- /row -->
      </section>
  </section>
  <script>
  function payWithPaystack(){

    var Amounts = document.getElementById("totAmount").value;
    var Emails = document.getElementById("email").value;

    var handler = PaystackPop.setup({
      key: 'pk_live_5d4c848943052093d8dbda5d2fd39b553a9aed56',
      email: Emails,
      amount: Amounts,
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "+2348012345678"
            }
         ]
      },
      callback: function(response){
          alert('success. transaction ref is ' + response.reference);
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
</script>
<script>
  //pk_live_5d4c848943052093d8dbda5d2fd39b553a9aed56
  $(document).ready(function() {
    $("#amount").keyup(function() {
      var charge = (Number($("#amount").val()) * 0.02);
      $("#total").val((Number($("#amount").val()) + charge ));
      $("#charge").val(charge)
    });
  });
</script>
<script src="https://js.paystack.co/v1/inline.js"></script>
  <!--main content end-->
  <!--footer start-->
  <?php require_once 'inc/foot.php' ?>