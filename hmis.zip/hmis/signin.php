<?php require_once 'inc/head.php'; ?>
<body class="hero">
<?php
$userid = "";
if(isset($_POST["ok-login"])){
  $userid = mysqli_real_escape_string($conn,$_POST["userid"]);
  $password = mysqli_real_escape_string($conn,$_POST["password"]);
  $sql = "SELECT * from hostel_students where userid = '$userid' ";
  
  $result = $conn->query($sql)or
  die(mysqli_error($conn));
  if($result->num_rows > 0){

    $rs = $result->fetch_assoc();

    if(password_verify($password, $rs["password"])){
      $_SESSION['userid'] = $rs['userid'];
      echo "<script>
              mscAlert({
                title: 'You have login successfully, click on OK to continue',
                okText: 'OK',
                dismissOverlay: true,

                onOk: function() {
                window.location.href='dashboard/dashboard';
                },
              });
            </script>";
      //header("location: ");
     }else{
      set_flash("Invalid username or password","danger");
     }
   }else{
    set_flash("Invalid username or password","danger");
   }
}
?>
    <section id="hero">
    <div class="hero-container">
      <div class="row">
          <div class="col-lg-12">
            <a href="default"><h2 class=""><span>Hostel</span> Management System</h2></a>
            <div class="w3l-login-form login">
                <h2>Student Login</h2>
                <?php echo flash(); ?>
                <form action="" method="POST">

                    <div class=" w3l-form-group">
                        <label>Student Roll No:</label>
                        <div class="group">
                            <i class="fas fa-user"></i>
                            <input type="text" class="form-control" name="userid" placeholder="Roll/Matric No" required="required" value="<?php echo($userid) ?>" />
                        </div>
                    </div>
                    <div class=" w3l-form-group">
                        <label>Password:</label>
                        <div class="group">
                            <i class="fas fa-unlock"></i>
                            <input type="password" class="form-control" name="password" placeholder="Password" required="required" />
                        </div>
                    </div>
                    <!--<div class="forgot">
                        <a href="#">Forgot Password?</a>
                        <p><input type="checkbox">Remember Me</p>
                    </div>-->
                    <button type="submit" name="ok-login">Login</button>
                </form>
                <p class=" w3l-register-p">Login as<a href="hostel_manager" class="register"> Hostel-Manager</a></p>
                <p class=" w3l-register-p">Don't have an account?<a href="signup" class="register"> Sign up</a></p>
            </div>
            <?php require_once 'inc/foot-text.php'; ?>
          </div>
      </div>
    </div>
  </section>
<?php require_once 'inc/foot.php'; ?>
