  
  <script src="dashboard/lib/DataTables/datatables.min.js"></script>
  <script src="dashboard/lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/lib/jquery.backstretch.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $(".hero").backstretch([
        "images/2.png",
        "images/3.png",
        "images/a.jpg",
        "images/cover3.jpg",
        "images/cover4.jpg",
      ], {duration: 5000, fade: 500});
    });
</script>
<script>
  if(window.history.replaceState) {
     window.history.replaceState(null, null, window.location.href);
  }
</script>
