	<footer>
        <p class="copyright-agileinfo"> &copy; 2018 - <?php echo date("Y"); ?> FPE Project. All Rights Reserved | Hostel  Allocation Management System</p>
    </footer>