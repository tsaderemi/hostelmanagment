<?php
include_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>HMS</title>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywords" content="Art Sign Up Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates,Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"/>
    <!-- /meta tags -->
    <!-- custom style sheet -->
    <link rel="icon" href="images/favicon.jpg">
    <link href="dashboard/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="dashboard/lib/DataTables/datatables.min.css">
      <!--external css-->
    <link href="web/css/fontawesome-all.css" rel="stylesheet" />
    <link href="dashboard/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
    <!-- /custom style sheet -->
    <!-- fontawesome css -->
    <link href="css/fontawesome-all.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="config/msc-style.css" />
    <script src="dashboard/lib/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="config/msc-script.js"></script>
    
    <!-- /fontawesome css -->
    <!-- google fonts-->
    <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- /google fonts-->
    <style type="text/css">
        .error{
          color: red !important;
          padding: 5px 2px !important;
        }
    </style>
</head>