<?php
include_once 'config.php';
include_once 'tcpdf/tcpdf.php';
	
	if(isset($_GET["reg"])){
    $reg = $_GET["reg"];
  }else{
    header("location: ../signin.php");
  }
  $record = "SELECT * from hostel_students where userid = '$reg' ";
  $recordRes = $conn->query($record)or
  die(mysqli_error($conn));
  $recordRs = $recordRes->fetch_assoc();
  $surname = strtoupper($recordRs['lastname']);
  $othernames = strtoupper($recordRs['firstname']);
  $gender = $recordRs['gender'];
  $year = $recordRs['year_of_study'];
  $department = $recordRs["department"];
  $passport = $recordRs['passport'];
  $phone = $recordRs["phone"];
  $email = $recordRs["email"];

  /*
  $class = "SELECT class from result_classes where regno = '$reg' and session = '$year' ";
  $classRes = $conn->query($class)or
  die(mysqli_error($conn));
  $classRs = $classRes->fetch_assoc();
  $class = $classRs["class"];

  
  $count = "SELECT count(*) as totalScore, sum(ca) as tCa, sum(exam) as tExam from `$year` where regno = '$reg' and term = '$term' and year = '$year' " ;
  $countRes = $conn->query($count)or
  die(mysqli_error($conn));

  $countRs = $countRes->fetch_assoc();
  $totalScore = $countRs['totalScore'] * 100;
  $studentScore = ($countRs['tCa'] + $countRs['tExam']);
  */
  $totalScore = "4000";
  $studentScore = "3420";
?>
<?php
/*
function fetch_programme(){
  $conts = '';
  include("../config/config.php");
    $reg = $_GET["regno"];
    $year = $_GET["session"];
    $term = $_GET["term"];

    $sql = "SELECT * from `$year` where regno = '$reg' and term = '$term' and year = '$year'";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));
    if($result->num_rows > 0){
      $sn = "";
      while($rs = $result->fetch_assoc()){
        $sn = ++$sn;
        $id = $rs["id"];
        $serials = $rs["serials"];
        $subject = $rs["subject"];
        $ca = $rs["ca"];
        $exam = $rs["exam"];

        $rate = "SELECT * from rating where id = '$sn' limit 5 ";
        $rateRes = $conn->query($rate)or
        die(mysqli_error($conn));
        $rateRs = $rateRes->fetch_assoc();
        $ratings = $rateRs["rating"];

        $total = ($ca + $exam);
        $remark = "";
        if ($total >= 75) {
          $remark = "A";
        }else if($total >= 65){
          $remark = "AB";
        }else if($total >= 55) {
          $remark = "B";
        }else if($total >= 50){
          $remark = "C";
        }else if($total >= 40){
          $remark = "D";
        }else{
          $remark = "E";
        }
    $conts .='
            <tr>
              <td>'.$subject.'</td>
              <td align="right">'.$ca.'</td>
              <td align="right">'.$exam.'</td>
              <td align="right">'.$total.'</td>
              <td align="center">'.$remark.'</td>
              <td align="center">'.$ratings.'</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          ';
        }
      }
  return $conts;
  }
*/
class MYPDF extends TCPDF {
  public function Header() {
    // Logo
    $logoX = 10; 
    $image_file = "header-log.jpg";
    $logoWidth = 190; // 15mm
    $this->Image($image_file, $logoX, $this->GetY()+0.8, $logoWidth);
    // Set font
  }
  public function Footer() {
    // Position at 15 mm from bottom
    /* Put your code here (see a working example below) */

   $logoX = 10; // 186mm. The logo will be displayed on the right side close to the border of the page
   $logoFileName = "lines.jpg";
   $logoWidth = 190; // 15mm
   $this->SetFont('times', 'I b', 9);
   $date = date("l, M d, Y, h:m:i a");
   $text = "Federal Poly Ede Hostel Manager ".date("Y");
   $logo = $this->Cell(0, 10, $text, 0, false, 'L', 0, '', 0, false, 'T', 'M').''.$this->Cell(0, 10, $date, 0, false, 'R', 0, '', 0, false, 'T', 'M').''. $this->Image($logoFileName, $logoX, $this->GetY()-0.8, $logoWidth);
  }
}
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
//$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$pdf->SetFont('times', '', 10);
$pdf->SetTitle("WOPS | Report Card");
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
$pdf->SetHeaderData(PDF_HEADER_TITLE, PDF_HEADER_STRING);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, 'times', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont('helvetica');
$pdf->setPrintHeader(TRUE);
$pdf->setPrintFooter(TRUE);
$pdf->SetFooterMargin(15);
$pdf->setHeaderMargin(5);
$pdf->setAutoPageBreak(TRUE, 10);
$pdf->setLeftMargin(9);
$pdf->setRightMargin(13);
$pdf->setTopMargin(35);
$pdf->setFont('times', '', 11.5);
$tagvs = array(
 'p' => array(0 => array('n' => 0, 'h' => ''), 1 => array('n' => 0, 'h' => ''))
 );
$pdf->setHtmlVSpace($tagvs);
$pdf->addPage();
$conts = '';
$conts .='
<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <table cellpadding="5" border="0">
      <tr>
        <td align="center" colspan="10"><h3>HOSTEL FEE PAYMENT</h3></td>
      </tr>
      <tr>
        <td align="right" colspan= width="30%">Registration Number:</td>
        <td width="50%"><b>'.$reg.'</b></td>
        <td colspan="4" rowspan="4" width="15%"><img src="../passport/'.$passport.'" width="88" height="93" /></td>
      </tr>
      <tr>
        <td align="right" width="30%">Surname</td>
        <td width="50%"><b>'.$surname.'</b></td>
      </tr>
      <tr>
        <td align="right" width="30%">Department</td>
        <td width="50%"><b>'.$department.'</b></td>
      </tr>
      <tr>
        <td align="right" width="30%">Phone Number</td>
        <td width="50%"><b>'.$phone.'</b></td>
      </tr>
      <tr>
        <td align="right" width="30%">Email</td>
        <td width="50%"><b>'.$email.'</b></td>
      </tr>
      <tr>
        <td align="right" width="30%">Year of Study</td>
        <td width="50%"><b>'.$year.'</b></td>
      </tr>
      <tr>
        <td align="right" width="30%">Gender</td>
        <td width="50%"><b>'.$gender.'</b></td>
      </tr>
    </table>
    <table border="0.1" width="100%" cellpadding="1">
      <tr>
        <td width="25%" align="center"><b>SUBJECT</b></td>
        <td width="7%"></td>
        <td width="8%"></td>
        <td width="9%"></td>
        <td width="12%"></td>
        <td width="27%" align="center"><b>SKILL & BEHAVIOUR</b></td>
        <td width="3%" align="center"><b>A</b></td>
        <td width="3%" align="center"><b>B</b></td>
        <td width="3%" align="center"><b>C</b></td>
        <td width="3%" align="center"><b>D</b></td>
      </tr>
      <tr>
        <td></td>
        <td align="center"><b>CA</b></td>
        <td align="center"><b>EXAM</b></td>
        <td align="center"><b>TOTAL</b></td>
        <td align="center"><b>REMARK</b></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>';
      //$conts .= fetch_programme();
      $conts .=
      '</table>
</body>
</html>';
$pdf->writeHTML($conts);
$pdf->OutPut("$reg/_/$year/_/Hostel Fee.pdf");
?> 



