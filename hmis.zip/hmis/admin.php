<?php require_once 'config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <title>Login | WayOut</title>

  <!-- Favicons -->
  <link href="assets/img/icon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="dashboard/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="dashboard/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/msc-style.css">
  <!-- Custom styles for this template -->
  <link href="dashboard/css/style.css" rel="stylesheet">
  <link href="dashboard/css/style-responsive.css" rel="stylesheet">


  <script src="dashboard/lib/jquery/jquery.min.js"></script>
  <script src="assets/js/msc-script.js"></script>

</head>

<body>
<?php
if(isset($_POST["ok-login"])){
  $username = mysqli_real_escape_string($conn,$_POST["username"]);
  $password = mysqli_real_escape_string($conn,$_POST["password"]);
  $sql = "SELECT * from student_login where username = '$username' ";
  
  $result = $conn->query($sql)or
  die(mysqli_error($conn));
  if($result->num_rows > 0){

    $rs = $result->fetch_assoc();

    if(password_verify($password, $rs["password"])){
      $_SESSION["student"] = $username;
      echo "<script>
              mscAlert({
                title: 'You have login successfully, click on OK to continue',
                okText: 'OK',
                dismissOverlay: true,

                onOk: function() {
                window.location.href='dashboard/dashboard';
                },
              });
            </script>";
      //header("location: ");
     }else{
      set_flash("Invalid username or password","danger");
     }
   }else{
    set_flash("Invalid username or password","danger");
   }
}
?>
  <div id="login-page">
    <div class="container">
      <form class="form-login" action="" method="post">
        <h2 class="form-login-heading">Student Login</h2>
        <div class="login-wrap">
          <?php echo flash(); ?>
          <input type="text" class="form-control" placeholder="User ID" autofocus name="username">
          <br>
          <input type="password" class="form-control" placeholder="Password" name="password">
          <label class="checkbox">
            <span style="margin-left: 20px;"><input type="checkbox" value="remember-me"> Remember me</span>
            <span class="pull-right">
            <!--<a data-toggle="modal" href="login.html#myModal"> Forgot Password?</a> -->
            </span>
            </label>
          <button class="btn btn-theme btn-block" name="ok-login" type="submit"><i class="fa fa-lock"></i> LOG IN</button>
          <hr>
          <div class="login-social-link centered">
            <p class="alert alert-info">Your registration number is your user Id and Password</p>
          </div>
        </div>
        <!-- Modal -->
        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Forgot Password ?</h4>
              </div>
              <div class="modal-body">
                <p>Enter your e-mail address below to reset your password.</p>
                <input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">
              </div>
              <div class="modal-footer">
                <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                <button class="btn btn-theme" type="button">Submit</button>
              </div>
            </div>
          </div>
        </div>
        <!-- modal -->
      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  
  <script src="dashboard/lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="dashboard/lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("assets/img/main-feature.jpg", {
      speed: 500
    });
  </script>
</body>

</html>
