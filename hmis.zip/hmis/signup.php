<?php require_once 'inc/head.php'; ?>
<body class="hero">
<?php
$res = "";
$matric = $student_lname = $student_fname = $gender = $department = $passport = $year = $phone = $password = $cpassword = $email = "";
$matricErr = $student_fnameErr = $student_lnameErr = $genderErr = $departmentErr = $yearErr = $passportErr = $phoneErr = $passwordErr = $cpasswordErr = $emailErr = "";
if(isset($_POST["ok-submit"])){

if(empty($_POST["matric"])){
    $matricErr = "<span class='error'>Input your matric number</span>";
}else{
    $matric = val_input($_POST["matric"]);
    $sql = "SELECT * from hostel_students where userid = '$matric' ";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));
    if($result->num_rows > 0){
        $matricErr = "<span class='error'>Matric or Roll number already exist</span>";
    }
}

  if(empty($_POST["student_lname"])){
    $student_lnameErr = "<span class='error'>Please fill out this field</span>";
  }else{
    $student_lname = val_input($_POST["student_lname"]);
    if(!preg_match("/^[a-zA-Z ]*$/",$student_lname)){
      $student_lnameErr = "<span class='error'>Only letters and white space allowed</span>";
  }
}

  if(empty($_POST["student_fname"])){
    $student_fnameErr = "<span class='error'>Please fill out this field</span>";
  }else{
    $student_fname = val_input($_POST["student_fname"]);
    if(!preg_match("/^[a-zA-Z ]*$/",$student_fname)){
      $student_fnameErr = "<span class='error'>Only letters and white space allowed</span>";
  }
}

  if(empty($_POST["email"])){
    $emailErr = "<span class='error'>Please, fill out this field</span>";
  }else{
    $email = val_input($_POST["email"]);
    if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
      $emailErr = "<span class='error'>Invalid email format</span>";
      }else{
        $sql = "SELECT * from hostel_students where email = '$email' ";
        $result = $conn->query($sql);
        if($result->num_rows > 0){
          $emailErr = "<span class='error'>Email alredy exist</span>";
      }
    }
  }

  if(empty($_POST["mobile_no"])){
    $phoneErr = "<span class='error'>Phone number is reqired</span>";
  }else{
    $phone = val_input($_POST["mobile_no"]);
    if(!preg_match("/^[0-9 +]*$/", $phone)){
        $phoneError = "Phone number must be digits only";
      }else{
        $phone = val_input($_POST["mobile_no"]);
        $sql = "SELECT * from hostel_students where phone = '$phone' ";
        $result = $conn->query($sql);
        if($result->num_rows > 0){
            $phoneError = "Phone number already exist, please use another phone number";
            echo "<script>document.getElementById('phoneError').style.display = 'block' </script>";
          }
        }
  }

  if(empty($_POST["department"])){
    $departmentErr = "<span class='error'>Select a department</span>";
  }else{
    $department = val_input($_POST["department"]);
  }

  if(empty($_POST["gender"])){
    $genderErr = "<span class='error'>Select a gender</span>";
  }else{
    $gender = val_input($_POST["gender"]);
  }

  if(empty($_POST["year"])){
    $yearErr = "<span class='error'>Enter a year of study</span>";
  }else{
    $year = val_input($_POST["year"]);
    //if(!preg_match("/^[0-9]*$/", $year))
  }

  if(empty($_FILES["passport"]["name"])){
        $passportErr = "<span class='error'>No file select</span>";
    }else{
        $target_file = "../payment/".basename($_FILES["passport"]["name"]);
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        $check = getimagesize($_FILES["passport"]["tmp_name"]);
        if($check === false) {
        $passportErr = "<span class='error'>File selected is not and image</span>";
        }else if($_FILES["passport"]["size"] > 500000) {
            $passportErr = "<span class='error'>File selected is too large, should not be more than 500kb</span";
        }else if($imageFileType == "gif") {
            $passportErr = "<span class='error'>Only jpeg, jpg and png images allowed</span>";
        }
    }

if(empty($_POST["password"])){
    $passwordErr = "<span class='error'>Password is required</span>";
  }else{
    $password = val_input($_POST["password"]);
        if(strlen($password) < 8){
          $passwordErr = "<span class='error'>Password must be at least 8 characters</span>";
        }
  }

  if(empty($_POST["cpassword"])){
    $cpasswordErr = "<span class='error'>Password confirmation is required</span>";
  }else{
    $cpassword = val_input($_POST["cpassword"]);
        $password = $_POST["password"];
        if($cpassword !== $password){
            $cpasswordErr = "<span class='error'>The password your entered does not match</span>";
        }
  }

  if(val_input($student_fnameErr) != null || val_input($student_lnameErr) != null || val_input($genderErr) != null || val_input($departmentErr) != null || val_input($yearErr) != null || val_input($passwordErr) != null || val_input($cpasswordErr) != null || val_input($phoneErr) != null || val_input($passportErr) != null || val_input($matricErr) != null || val_input($emailErr) != null){
        echo "<script> alert('There was error is registration, check that all fields are properly filled');</script>";
        set_flash("There was error is registration, check that all fields are properly filled","danger");
    }else{

    $matric = mysqli_real_escape_string($conn,$_POST["matric"]);
    $student_lname = mysqli_real_escape_string($conn,$_POST["student_lname"]);
    $student_fname = mysqli_real_escape_string($conn,$_POST["student_fname"]);
    $department = mysqli_real_escape_string($conn,$_POST["department"]);
    $gender = mysqli_real_escape_string($conn,$_POST["gender"]);
    $year = mysqli_real_escape_string($conn,$_POST["year"]);
    $phone = mysqli_real_escape_string($conn,$_POST["mobile_no"]);
    $email = mysqli_real_escape_string($conn,$_POST["email"]);
    $password = mysqli_real_escape_string($conn,password_hash($_POST["password"],PASSWORD_DEFAULT));

    $passport = mysqli_real_escape_string($conn,$_FILES["passport"]["name"]);
    $ext = explode('.', $passport);
    $ext = end($ext);
    $newfilename = $matric.".";
    $newfilename = $newfilename.$ext;
    $passport = htmlspecialchars($newfilename);
    $target = "passport/".$newfilename;
             
    $sql = "INSERT into hostel_students (userid,firstname,lastname,department,gender,phone,email,year_of_study,passport,password) values ('$matric','$student_fname','$student_lname','$department','$gender','$phone','$email','$year','$passport','$password')";
    $res = $conn->query($sql)or
    die(mysqli_error($conn));

    move_uploaded_file($_FILES['passport']['tmp_name'], $target);
    if($res === TRUE){
    $sql = "INSERT into hostel_fee (userid,payment,status,others) values('$matric','0','0','0')";
    $results = $conn->query($sql)or
    die(mysqli_error($conn));

    if($results){
      echo "<script>
            mscConfirm({
              title: 'Success',
              subtitle: 'Proceed to login?',
              okText: 'Ok',
              cancelText: 'Cancel',
              dismissOverlay: true,
              onOk: function() {
                window.location.href='signin';
              },
              onCancel: function() {
                window.location.href='signup';
              }
            });
          </script>";
        //unset($_SESSION["userid"]);
    }else{
       echo "<script>alert('There was in submitting your data, check that all fields are properly filled')</script>";
        set_flash("There was error in submitting your data, check that all fields are properly filled","danger");
    }
  }else{
    echo "<script>alert('There was in submitting your data, check that all fields are properly filled')</script>";
      set_flash("There was error in submitting your data, check that all fields are properly filled","danger");
    }
  }
}


function val_input($data){
  $data = trim($data);
  $data = stripcslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
    <section id="hero">
    <div class="hero-container">
      <div class="row">
          <div class="col-lg-12">
            <a href="default"><h2 class=""><span>Hostel</span> Management System</h2></a>
            <div class=" w3l-login-form signup">
                <h2>Sign Up Here</h2>
                <div class="row">
                    <form action="" method="POST" name="signup" enctype="multipart/form-data">
                        <div class="col-lg-6">
                            <div class=" w3l-form-group">
                                <label>Roll No/Matric No</label>
                                <div class="group">
                                    <i class="fas fa-id-badge"></i>
                                    <input type="text" class="form-control" name="matric" placeholder="Roll No/Matric No" required="required" value="<?php if(!$res){echo($matric);} ?>" />
                                </div>
                                <?php echo $matricErr; ?>
                            </div>
                            <div class=" w3l-form-group">
                                <label>Surname Name</label>
                                <div class="group">
                                    <i class="fas fa-user"></i>
                                    <input type="text" class="form-control" name="student_lname" placeholder="Last Name" required="required" value="<?php if(!$res){echo($student_lname);} ?>" />
                                </div>
                                <?php echo $student_lnameErr; ?>
                            </div>
                            <div class=" w3l-form-group">
                                <label>Other Names</label>
                                <div class="group">
                                    <i class="fas fa-user"></i>
                                    <input type="text" class="form-control" name="student_fname" placeholder="First Name" required="required" value="<?php if(!$res){echo($student_fname);} ?>" />
                                    <?php echo $student_fnameErr ; ?>
                                </div>
                            </div>
                            <div class=" w3l-form-group">
                                <label>Mobile No</label>
                                <div class="group">
                                    <i class="fas fa-phone"></i>
                                    <input type="text" class="form-control" name="mobile_no" placeholder="Mobile No" required="required" value="<?php if(!$res){echo($phone);} ?>" />
                                </div>
                                <?php echo $phoneErr; ?>
                            </div>
                            <div class=" w3l-form-group">
                                <label>Passport</label>
                                <div class="group">
                                    <i class="fas fa-image"></i>
                                    <input type="file" class="form-control" name="passport" required="required" value="<?php if(!$res){echo($passport);} ?>" />
                                    
                                </div>
                                <?php echo $passportErr; ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class=" w3l-form-group">
                                    <label>Department</label>
                                    <div class="group">
                                        <i class="fas fa-graduation-cap"></i>
                                        <select class="form-control" name="department" required="required">
                                            <?php
                                            if(!$res){
                                            ?>
                                            <option><?php echo $department; ?></option>
                                            <?php
                                            }
                                            ?>
                                            <option></option>
                                            <option>Cpmputer Science</option>
                                            <option>Statistics</option>
                                        </select>
                                        
                                    </div>
                                    <?php echo $departmentErr; ?>
                                </div>
                                <div class=" w3l-form-group">
                                    <label>Year of Study</label>
                                    <div class="group">
                                        <i class="fas fa-calendar"></i>
                                        <input type="text" class="form-control" name="year" placeholder="2018/2019" required="required" value="<?php if(!$res){echo($year);} ?>" />
                                        
                                    </div>
                                    <?php echo $yearErr; ?>
                                </div>
                                <div class=" w3l-form-group">
                                    <label>Gender</label>
                                    <div class="group">
                                        <i class="fas fa-male"></i>
                                        <select name="gender" class="form-control" required="">
                                            <?php
                                            if(!$res){
                                            ?>
                                            <option><?php echo $gender; ?></option>
                                            <?php
                                            }
                                            ?>
                                            <option></option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                        
                                    </div>
                                    <?php echo $genderErr; ?>
                                </div>

                                

                                <div class=" w3l-form-group">
                                    <label>Password:</label>
                                    <div class="group">
                                        <i class="fas fa-unlock"></i>
                                        <input type="password" class="form-control" name="password" placeholder="Password" required="required" />
                                    </div>
                                    <?php echo $passwordErr; ?>
                                </div>

                                <div class=" w3l-form-group">
                                    <label>Confirm Password:</label>
                                    <div class="group">
                                        <i class="fas fa-unlock"></i>
                                        <input type="password" class="form-control" name="cpassword" placeholder="Confirm Password" required="required" />
                                    </div>
                                    <?php echo $cpasswordErr; ?>
                                </div>

                              </div>
                              <div class="col-lg-12 w3l-form-group" style="margin-top: -3px;">
                                <label>Email:</label>
                                <div class="group">
                                    <i class="fas fa-envelope"></i>
                                    <input type="email" class="form-control" name="email" placeholder="Email" required="required" value="<?php if(!$res){echo($email);} ?>" />
                                </div>
                                <?php echo $emailErr; ?>
                              </div>
                              <div class="col-lg-12 text-center">
                                  <button type="submit" name="ok-submit">Sign Up</button>
                              </div>
                     </form>
                </div>
                <p class=" w3l-register-p">Already a Member?<a href="signin" class="register"> Login</a></p>
            </div>
            <?php require_once 'inc/foot-text.php'; ?>
        </div>
        </div>
    </div>
    </section>
</body>
</html>
<?php require_once 'inc/foot.php'; ?>
