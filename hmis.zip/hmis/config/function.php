<?php

	define( 'TIMEBEFORE_NOW','now' );
    define( 'TIMEBEFORE_MINUTE','{num} minute ago' );
    define( 'TIMEBEFORE_MINUTES','{num} minutes ago' );
    define( 'TIMEBEFORE_HOUR', '{num} hour ago' );
    define( 'TIMEBEFORE_HOURS', '{num} hours ago' );
    define( 'TIMEBEFORE_YESTERDAY', 'yesterday' );
    define( 'TIMEBEFORE_FORMAT',  '%e %b' );
    define( 'TIMEBEFORE_FORMAT_YEAR', '%e %b, %Y' );

    define( 'TIMEBEFORE_DAYS',    '{num} days ago' );
	define( 'TIMEBEFORE_WEEK',    '{num} week ago' );
	define( 'TIMEBEFORE_WEEKS',   '{num} weeks ago' );
	define( 'TIMEBEFORE_MONTH',   '{num} month ago' );
	define( 'TIMEBEFORE_MONTHS',  '{num} months ago' );

	date_default_timezone_set("Africa/Lagos");

	function admin()
	{
		if(!isset($_SESSION['admin'])){
			return false;
		}else{
			return true;
		}
	}


    function staff_admin()
    {
        if(!isset($_SESSION['staff'])){
            return false;
        }else{
            return true;
        }
    }


	function set_flash($msg,$type)
	{
		$_SESSION['flash'] = "<div class='alert alert-".$type."'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>".$msg."</div>";
	}

	function flash()
	{
		if(isset($_SESSION['flash']))
		{
			echo $_SESSION['flash'];
			unset($_SESSION['flash']);
		}
	}



    function set_logins($msg,$type){
        $_SESSION["logins"] = "<div class='alert alert-".$type."'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>".$msg."</div>";
    }
    function set_signup($msg,$type){
        $_SESSION["signup"] = "<div class='alert alert-".$type."'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>".$msg."</div>";
    }

    function logins(){
        if(isset($_SESSION["logins"])){
            echo $_SESSION["logins"];
            unset($_SESSION["logins"]);
        }
    }
    function signup(){
        if(isset($_SESSION["signup"])){
            echo $_SESSION["signup"];
            unset($_SESSION["signup"]);
        }
    }
    function btcClass($status){
        if($status == 1){
            echo "success";
        }else if($status == 0){
            echo "warning";
        }
    }

    function btcClassFee($status){
        if($status == 1){
            echo "success";
        }else if($status == 0){
            echo "danger";
        }
    }
	function num_formats($n)
	{
		$l = strlen($n);
		if($l == 1){
			return "00".$n."00";
		}elseif ($n == 2) {
			return "0".$n."00";
		}else{
			return $n."00";
		}
	}

	function admin_role($n)
	{
		if($n == "Mode"){
			return "Moderator";
		}elseif ($n == "Admin") {
			return "Global Admin";
		}elseif($sn == "Manager"){
            return "Hostel Manager";
        }
	}


    function alert($msg,$type,$close = false)
    {
        if($close == false){
            $msg = "<div class='alert alert-".$type."'>".$msg."</div>";
        }else{
            $msg = "<div class='alert alert-".$type."'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>".$msg."</div>";
        }

        echo $msg;
    }
    function all_rooms(){
    	$sql = "SELECT * from hostel_rooms ";
    	$result = $conn->query($sql)or
    	die(mysqli_error($conn));
    	if($result->num_rows > 0){
    		return $rs = $result->fetch_assoc();
    	}
    }

	function site_name(){
		return "Hostel Management";
	}


    function hostel_names($conn){

        $sql = "SELECT * from hostel_names";

        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        while($rs = $result->fetch_assoc()){

            $hostname = $rs["hostel_name"];
            $hostid = $rs["hostel_id"];
            echo "<option value=".$hostid.">".$hostname."</option>";
            
        }   
    }

    function allocate_hostel($conn,$gender){
        $sql = "SELECT * from hostel_names where hostel_category = '$gender' ";

        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        while($rs = $result->fetch_assoc()){

            $hostname = $rs["hostel_name"];
            $hostid = $rs["hostel_id"];
            $block = $rs["block_name"];
            echo "<option value=".$hostid.">".$hostname." ".$block."</option>";
            
        }   
    }
    function hostel_assign($conn,$hostid){
        $sql = "SELECT block_name, hostel_name from hostel_names where hostel_id = '$hostid' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        if($result->num_rows > 0){
            $rs = $result->fetch_assoc();
            $hostname = $rs["hostel_name"];
            $hostblock = $rs["block_name"];

            echo $hostblock." ".$hostname;
        }
    }

    function available_rooms($conn,$hostid){
        $sql = "SELECT count(*) as availablerooms from hostel_rooms where hostel_id = '$hostid' and status = '2' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        if($result->num_rows > 0){
            $rs = $result->fetch_assoc();
            $availablerooms = $rs["availablerooms"];

            echo $availablerooms;
        }
    }

    function faulty_rooms($conn){
        $sql = "SELECT count(*) as faulty_rooms from hostel_rooms where condition = 'Faulty' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        if($result->num_rows > 0){
            $rs = $result->fetch_assoc();
            $faultyrooms = $rs["faulty_rooms"];
            echo $faultyrooms;

        }
    }

    function hostelId($qtd){
        $Caracteres = '23456789';
        $QuantidadeCaracteres = strlen($Caracteres);
        $QuantidadeCaracteres--;
        $Hash=NULL;
        for($x=1; $x<=$qtd; $x++){
            $Posicao = rand(0,$QuantidadeCaracteres);
            $Hash .= substr($Caracteres,$Posicao,1);
        }
        return $Hash;
    }
    $hostelId =  hostelId(3);

    function hostel_manager($conn,$id){
        $sql = "SELECT name from hostel_managers where hostel = '$id' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        if($result->num_rows > 0){
            $rs = $result->fetch_assoc();
            $mname = $rs["name"];

            echo $mname;
        }
    }
    function roomId($qtd){
        $Caracteres = '23456789';
        $QuantidadeCaracteres = strlen($Caracteres);
        $QuantidadeCaracteres--;
        $Hash=NULL;
        for($x=1; $x<=$qtd; $x++){
            $Posicao = rand(0,$QuantidadeCaracteres);
            $Hash .= substr($Caracteres,$Posicao,1);
        }
        return $Hash;
    }
    $roomId =  roomId(4);


    function booking_hostel($conn,$gender){
        $sql = "SELECT block_name, hostel_id, hostel_name from hostel_names where hostel_category = '$gender' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
        if($result->num_rows > 0)
            if($result->num_rows > 0){
                while($rs = $result->fetch_assoc()){
                    $hostname = $rs["hostel_name"];
                    $hostid = $rs["hostel_id"];

                    echo "<option value=".$hostid.">".$hostname."</option>";
                }
        }
    }

    function view_hostel($conn,$hostelid){
        $hblock  = "SELECT * from hostel_names where hostel_id = '$hostelid' ";
        $hblockRes = $conn->query($hblock)or
        die(mysqli_error($conn));
        if($hblockRes->num_rows > 0){
            $hblockRs = $hblockRes->fetch_assoc();

            echo $hblockRs["hostel_name"]." ".$hblockRs["block_name"];
        }
    }
?>