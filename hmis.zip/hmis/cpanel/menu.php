<?php
//$admin_name = $_SESSION['admin_name'];
//$admin_role = admin_role($_SESSION['admin_role']);
?>
<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard">
        <div class="sidebar-brand-icon rotate-n-15">
          HM
        </div>
        <div class="sidebar-brand-text mx-3"> Hostel Management</div>
      </a>
      
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="fa fa-fw fa-dashboard"></i>
          <span>Dashboard</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#students" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-users"></i>
          <span>Students</span>
        </a>
        <div id="students" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="students?act=active">Active Students</a>
            <a class="collapse-item" href="students?act=domant">Domant Students</a>
            <a class="collapse-item" href="students">All Students</a>
            <a class="collapse-item" href="students">View/Delete Students</a>
          </div>
        </div>
      </li>
      <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#managers" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-user"></i>
          <span>Hostel Managers</span>
        </a>
        <div id="managers" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="managers.php?act=add">Add Manager</a>
            <a class="collapse-item" href="managers">Vewi/Edit/Del Managers</a>
            <a class="collapse-item" href="managers">All Hostel Managers</a>
          </div>
        </div>
      </li>
      <?php
        }
      ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#hostels" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-bank"></i>
          <span>Hostels</span>
        </a>
        <div id="hostels" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <?php
            if($_SESSION["admin_role"] == "admin"){
            ?>
            <a class="collapse-item" href="hostels.php?act=add">Add Hostel</a>
            <?php
              }
            ?>
            <a class="collapse-item" href="hostels">View/Edit/Del Hostel</a>
            <a class="collapse-item" href="hostels">All Hostels</a>
          </div>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#rooms" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-bed"></i>
          <span>Rooms</span>
        </a>
        <div id="rooms" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
            <a class="collapse-item" href="rooms.php?act=add">Add Room</a>
            <?php
              }
              $blocks = "SELECT * from hostel_names ";
              $blocksRes = $conn->query($blocks)or
              die(mysqli_error($conn));
              if($blocksRes->num_rows > 0){
                while($blocksRs = $blocksRes->fetch_assoc()){
            ?>
            <a class="collapse-item" href="rooms.php?act=view_rooms&id=<?php echo($blocksRs["hostel_id"]) ?>">Block <?php echo $blocksRs["block_name"]; ?></a>
            <?php
                }
              }
            ?>
            <a class="collapse-item" href="rooms.php?act=faulty">Faulty Rooms</a>
            <a class="collapse-item" href="rooms">All Rooms</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#application" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-edit"></i>
          <span>Applications</span>
        </a>
        <div id="application" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="applications?act=pending">Pending Applications</a>
            <a class="collapse-item" href="applications?act=approved">Approved Applications</a>
            <a class="collapse-item" href="applications">All Applications</a>
            <a class="collapse-item" href="applications?act=vercate">Vercate Room</a>
          </div>
        </div>
      </li>
      <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard#" data-toggle="collapse" data-target="#admin" aria-expanded="true" aria-controls="wallet">
          <i class="fa fa-fw fa-user-secret"></i>
          <span>Admin</span>
        </a>
        <div id="admin" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="admin.php?act=add">Add Admin</a>
            <a class="collapse-item" href="admin.php?act=view">View/Edit/Del Admin</a>
            <a class="collapse-item" href="admin">All Admins</a>
          </div>
        </div>
      </li>
      <?php
        }
      ?>
      <li class="nav-item">
        <a class="nav-link" href="password">
          <i class="fa fa-fw fa-lock"></i>
          <span>Password</span></a>
      </li>
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="dashboard#" data-toggle="modal" data-target="#logoutModal">
          <i class="fa fa-fw fa-sign-out"></i>
          <span>Logout</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->