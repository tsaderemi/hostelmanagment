<?php
require_once '../config/config.php'; 
  /*
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  */
  $page_title = "Hostel Applications";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';

  if(isset($_POST["ok-allocate"])){
    $roomid = mysqli_real_escape_string($conn,$_POST["rooms"]);
    $hostelid = mysqli_real_escape_string($conn,$_POST["hostels"]);
    $userid = mysqli_real_escape_string($conn,$_POST["userid"]);

    $print = "SELECT * from hostel_rooms where hostel_id = '$hostelid' and id = '$roomid' ";
    $printRes = $conn->query($print)or
    die(mysqli_error($conn));
    $printRs = $printRes->fetch_assoc();
    $capacity = $printRs["capacity"];
    $occupy = $printRs["num_occupy"];

    $roomno = $printRs["room_number"];

    $newOcc = $occupy + 1;

    //Update number of occupation on the room
    $sql = "UPDATE hostel_rooms set num_occupy = '$newOcc' where hostel_id = '$hostelid' and id = '$roomid' ";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));
    if($result === TRUE){
      set_flash("Hostel room allocated successfull","success");

      if($newOcc < $capacity){
        //Update room status to free
        $sql = "UPDATE hostel_rooms set status = 1 where hostel_id = '$hostelid' and id = '$roomid' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
      }else if($newOcc == $capacity){
        //Update room status to occupied
        $sql = "UPDATE hostel_rooms set status = 0 where hostel_id = '$hostelid' and id = '$roomid' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));
      }

      //Update the students room application to the select rooms
      $sql = "UPDATE hostel_application set hostel_id = '$hostelid', status = 1, room_no = '$roomno' where userid = '$userid' ";
      $result = $conn->query($sql)or
      die(mysqli_error($conn));

    }else{
      set_flash("There was error in allocating room to this user","danger");
    }
  }

  if(isset($_POST["vercate"])){
    $roomid = mysqli_real_escape_string($conn,$_POST["roomid"]);
    $hostelid = mysqli_real_escape_string($conn,$_POST["hostelid"]);
    $matric = mysqli_real_escape_string($conn,$_POST["matric"]);

    $sql = "SELECT * from hostel_rooms where room_id = '$roomid' and hostel_id = '$hostelid' ";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));
    if($result->num_rows == 0){
      set_flash("Invalid hostel or room id, make sure you type in the correct hostel and room id respectively","danger");
    }else{
      $rs = $result->fetch_assoc();
      $capacity = $rs["capacity"];
      $occupy = $rs["num_occupy"];
      $roomno = $rs["room_number"];

      $newSpace = $occupy - 1;

      //Update number of occupation on the room
      $sql = "UPDATE hostel_rooms set num_occupy = '$newSpace' where hostel_id = '$hostelid' and room_id = '$roomid' ";
      $result = $conn->query($sql)or
      die(mysqli_error($conn));
      if($result === TRUE){
        set_flash("Hostel room has been vercated successfully","success");

        if($newSpace > 0 ){
          //Update room status to free
          $sql = "UPDATE hostel_rooms set status = 1 where hostel_id = '$hostelid' and room_id = '$roomid' ";
          $result = $conn->query($sql)or
          die(mysqli_error($conn));
        }else if($newSpace == 0 ){
          //Update room status to occupied
          $sql = "UPDATE hostel_rooms set status = 2 where hostel_id = '$hostelid' and room_id = '$roomid' ";
          $result = $conn->query($sql)or
          die(mysqli_error($conn));
        }

        //Delete hostel appplication for this user
        $sql = "DELETE from hostel_application where userid = '$matric' ";
        $result = $conn->query($sql)or
        die(mysqli_error($conn));

        //Delete hostel fee for this user
        $deletFee = "UPDATE hostel_fee set payment = 0, status = 0, others = 0 where userid = '$matric' ";
        $deletFeeRes = $conn->query($deletFee)or
        die(mysqli_error($conn));


      }else{
        set_flash("There was error in allocating room to this user","danger");
      }

    }
  }
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      
      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include_once 'top-nav.php'; ?>
        <!-- End of Topbar -->
        
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        <section class="content-header">
          <h1>
            <?php echo $page_title; ?>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li class="active"><?php echo $page_title; ?></li>
          </ol>
        </section>
          <!-- Content Row -->
          <?php 
          if(isset($_GET["act"])){
            switch ($_GET["act"]) {
              case 'view':
                include_once 'inc/view_application.php';
                break;

              case 'pending':
                include_once 'inc/pending_applications.php';
                break;

              case 'approved':
                include_once 'inc/approved_applications.php';
                break;

              case 'view_rooms':
                include_once 'inc/view_block_rooms.php';
                break;

              case 'vercate':
                include_once 'inc/vercate_room.php';
                break;

              default:
                # code...
                break;
            }
          }else{
            include_once 'inc/all_applications.php';
          }

          ?>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      

<?php include_once 'foot.php'; ?>