<!DOCTYPE html>
<!-- saved from url=(0053)https://mtndatashop.com/olastech/referral-transaction -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Referral Transaction</title>

  <!-- Custom fonts for this template-->
  <link href="./Referral my_files/all.min.css" rel="stylesheet" type="text/css">
  <link href="./Referral my_files/css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="./Referral my_files/sb-admin-2.min.css" rel="stylesheet">
    <link href="./Referral my_files/hydrogenblue.css" rel="stylesheet">
  <script src="./Referral my_files/jquery-2.2.3.min.js.download"></script>
  <script src="./Referral my_files/vtutop.js.download"></script>
    <script src="./Referral my_files/flwpbf-inline.js.download"></script>
    <script src="./Referral my_files/inline.js.download"></script>
<link id="avast_os_ext_custom_font" href="chrome-extension://eofcbnmajmjmplflapaojjnihcjkigck/common/ui/fonts/fonts.css" rel="stylesheet" type="text/css"><link id="load-css-button.min.css" rel="stylesheet" type="text/css" href="./Referral my_files/button.min.css"></head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
 
    
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="https://mtndatashop.com/olastech/dashboard">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-signal"></i>
        </div>
        <div class="sidebar-brand-text mx-3"> Zeezmobile.com</div>
      </a>
      
      <hr class="sidebar-divider my-0">
        <p style="margin: 7%; color: #fff">
            <b>Referral Comm: <br> ₦0.00</b>
        </p>
        
              <li class="nav-item ">
        <a class="nav-link" href="https://mtndatashop.com/olastech/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
             
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/news">
          <i class="fas fa-fw fa-bullhorn"></i>
          <span>News Board</span></a>
      </li>
        
        <li class="nav-item" style="display: none">
            <a class="nav-link collapsed" href="https://mtndatashop.com/olastech/referral-transaction#" data-toggle="collapse" data-target="#servCent" aria-expanded="true" aria-controls="wallet">
              <i class="fas fa-fw fa-user"></i>
              <span>Service Center</span>
            </a>
            <div id="servCent" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="https://mtndatashop.com/olastech/productStatus">Products Status</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/offrecord">Offline Service</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/support">Helpdesk</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/members_stats">Portal Guide</a>
                              </div>
            </div>
          </li>
      
      <!-- Divider -->
      <hr class="sidebar-divider">
      
              
      <li class="nav-item">
        <a class="nav-link collapsed" href="https://mtndatashop.com/olastech/referral-transaction#" data-toggle="collapse" data-target="#wallet" aria-expanded="true" aria-controls="wallet">
          <i class="fas fa-fw fa-user"></i>
          <span>My Account</span>
        </a>
        <div id="wallet" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="https://mtndatashop.com/olastech/wallet">Add Money</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/share-money">Share Money</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/convertBonus">Wallet Transfer</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/transacts">All Transactions</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/referral-transaction">Referral Earning</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/priceList">Price List</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/updateProfile">Update Profile</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/change-password">Change Password</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/upgrade-plan">Upgrade Plan</a>
                      </div>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/airtime_topup">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Artime Topup</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/mtndata">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>MTN Data Bundle</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/referral-transaction#" data-toggle="modal" data-target="#logoutModal">
          <i class="fas fa-fw fa-unlock"></i>
          <span>Logout</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">


            <!-- Nav Item - Alerts -->
            
            <!-- Nav Item - Messages -->
            
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="https://mtndatashop.com/olastech/referral-transaction#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    Taiwo Sarafa<br>08030891417</span>
                <div class="img rounded-circle">
                    <i class="fa fa-user fa-2x"></i>
                </div>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                
                    <a class="dropdown-item" href="https://mtndatashop.com/olastech/referral-transaction#">
                      <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                      Payment History
                    </a>
                    <a class="dropdown-item" href="https://mtndatashop.com/olastech/referral-transaction#">
                      <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                      Manage Product
                    </a>
                                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="https://mtndatashop.com/olastech/referral-transaction#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">My Referrals</h1>
            <div id="usrbal">    
    <div class="row">
            
        <div class="col-md-6">
            <div style="background: #fff; color: #000; font-size: 18px; padding: 7px; border-bottom: 3px solid #36b9cc">
            	<b><font color="#36b9cc">Wallet Blc:</font> ₦0.00</b>
            </div>
        </div>
        
        <div class="col-md-6">
            <div style="background: #fff; color: #000; font-size: 18px; padding: 7px; border-bottom: 3px solid #ff0000">
            	<b><font color="#ff0000">Plan Level: </font> <br> Starter            </b></div><b>
        </b></div><b>
    </b></div><b>
</b></div>
          </div>

            <div style="font-size: 18px; margin-bottom: 3%; margin-top: 10px;">
                                Your referral link: mtndatashop.com/olastech/?register=08030891417                <br>Available Referral Bonus: <b>₦0.00</b> 
                
            </div>
        
          <!-- Content Row -->
          <div class="row">
            <div class="col-md-12">
                <ul class="nav nav-tabs">
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="https://mtndatashop.com/olastech/referral-transaction#addMoney">My Referrals</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="https://mtndatashop.com/olastech/referral-transaction#transHist">Referral Commission</a>
                </li>
              </ul>
            
              <!-- Tab panes -->
              <div class="tab-content">
                <div id="addMoney" class="container tab-pane active"><br>
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover dataTable no-footer" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                                <th>SN</th>
            	                <th>Name</th>
            	                <th>Email</th>
            	                <th>Mobile Number</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                                                    </tr>
                            </tbody>
                          
                        </table>
                    </div>
                    
                </div>
                <div id="transHist" class="container tab-pane fade"><br>
                 <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">Wallet History</h6>
                    </div>
                    <div class="card-body">
                         <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                    <th>SN</th>
                	                <th>Date</th>
                	                <th>Referral</th>
                	                <th>Order</th>
                	                <th>Commission</th>
                	                <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                                                            </tr>
                                </tbody>
                              
                            </table>
                          </div>
                      </div>          
                    </div>

                </div>
              </div>
            </div>
          </div> <br><br><br><br><br><br>

          
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
        <!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Thanks for using our services. We hope to see you soon.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Keep Using Service</button>
          <a class="btn btn-primary" href="https://mtndatashop.com/olastech/logout">Logout</a>
        </div>
      </div>
    </div>
</div>

<div style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;">
    <a href="https://api.whatsapp.com/send?phone=2348138311449&amp;text=I%27ll%20like%20to%20know%20more%20about%20Data%20bundle" target="_blank">
        <img src="./Referral my_files/whatsapp.png" width="90" height="90"></a>
</div>
<footer class="sticky-footer" style="background: #000; color: #fff">
    
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span style="font-size: 24px"><b>©  Zeezmobile.com </b></span>
            
            <div style="margin-top: 10px; font-size: 18px">
                <b>Email: </b><a href="mail:abdulazeezolawalea@gmail.com" style="color: #fff">abdulazeezolawalea@gmail.com</a> || 
                <b>Support: </b> 08138311449            </div>
        </div>
    </div>
</footer>      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="https://mtndatashop.com/olastech/referral-transaction#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

    <script>
        document.getElementById("mybtn").disabled = true;
        function confirmation(){
    	    document.getElementById('myForm').submit();
    	}
    	
    	function chkbtn(){
    		var amount = document.getElementById('amount').value;
    		var receiver = document.getElementById('rcvmobileNumb').value;
    		var currPass = document.getElementById('currPass').value;
    		var userName = document.getElementById('userName').value;
    		
    		if ((amount >= 1) && (receiver != '') && (currPass != '') && (userName != '')){
    			mybtn.disabled = false;
    		} else {
    			mybtn.disabled  = true;
    		}
    	}
    	
    	function confirmation(){
    	    document.getElementById('myForm').submit();
    	}

        $(document).ready(function(){
        	$("#mybtn").click(function(){
            	$('#modal22').modal('show');
        
        		document.getElementById('amntlbl').innerHTML = document.getElementById('amount').value;
        		document.getElementById('amntlbl2').innerHTML = document.getElementById('amount').value;
        		//recipent
        		document.getElementById('rcvlbl').innerHTML = document.getElementById('rcvmobileNumb').value;
        	});
        
        });
    </script>
    
    
  <!-- Bootstrap core JavaScript-->
  <script src="./Referral my_files/jquery.min.js.download"></script>
  <script src="./Referral my_files/bootstrap.bundle.min.js.download"></script>

  <!-- Core plugin JavaScript-->
  <script src="./Referral my_files/jquery.easing.min.js.download"></script>

  <!-- Custom scripts for all pages-->
  <script src="./Referral my_files/sb-admin-2.min.js.download"></script>

  <script src="./Referral my_files/jquery.dataTables.min.js.download"></script>
  <script src="./Referral my_files/dataTables.bootstrap4.min.js.download"></script>

  <!-- Page level custom scripts -->
  <script src="./Referral my_files/datatables-demo.js.download"></script>




<iframe frameborder="0" allowtransparency="true" id="JPLZx" name="paystack-checkout-background-JPLZx" style="z-index: 2147483647; background: rgba(0, 0, 0, 0.75); border: 0px none transparent; overflow: hidden; margin: 0px; padding: 0px; -webkit-tap-highlight-color: transparent; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; transition: opacity 0.3s ease 0s; visibility: hidden; display: none;" src="./Referral my_files/saved_resource.html"></iframe><iframe frameborder="0" allowtransparency="true" allowpaymentrequest="true" id="64Au8" name="paystack-checkout-64Au8" src="./Referral my_files/popup.html" style="z-index: 2147483647; background: transparent; border: 0px none transparent; overflow: hidden; margin: 0px; padding: 0px; -webkit-tap-highlight-color: transparent; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; visibility: hidden; display: none;"></iframe></body></html>