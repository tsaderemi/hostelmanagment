<?php
require_once '../config/config.php'; 
  /*
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  */
  $page_title = "Hostels";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';



  if(isset($_POST["ok-add"])){
    $hostelid = mysqli_real_escape_string($conn,$_POST["hostelid"]);
    $hostelname = mysqli_real_escape_string($conn,$_POST["hname"]);
    $block = mysqli_real_escape_string($conn,$_POST["block"]);
    $noroom = mysqli_real_escape_string($conn,$_POST["noroom"]);
    $capacity = mysqli_real_escape_string($conn,$_POST["capacity"]);
    $totcapacity = mysqli_real_escape_string($conn,$_POST["totcapacity"]);
    $category = mysqli_real_escape_string($conn,$_POST["category"]);

    $sql = "INSERT into hostel_names (hostel_id,hostel_name,block_name,total_rooms,capacity_per_room,capacity,hostel_category) values ('$hostelid','$hostelname','$block','$noroom','$capacity','$totcapacity','$category') ";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));

    if($result === TRUE){
      set_flash("New hostel Added successfully","success");
    }else{
      set_flash("There was error in adding new hostel","danger");
    }

    $count = 1;
    while($count <= $noroom) {

    $roomIds = rand(9,9999);

      $sql = "INSERT into hostel_rooms (room_id,hostel_id,room_number,capacity,status,conditions) values ('$roomIds','$hostelid','$count','$capacity','2','1')";
      $result = $conn->query($sql)or
      die(mysqli_error($conn));
      $count++;
    }
  }
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      
      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include_once 'top-nav.php'; ?>
        <!-- End of Topbar -->
        
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        <section class="content-header">
          <h1>
            <?php echo $page_title; ?>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li class="active"><?php echo $page_title; ?></li>
          </ol>
        </section>
          <!-- Content Row -->
          <?php 
          if(isset($_GET["act"])){
            switch ($_GET["act"]) {
              case 'view':
                include_once 'inc/view_hostels.php';
                break;

              case 'add':
                include_once 'inc/add_hostel.php';
                break;


              default:
                # code...
                break;
            }
          }else{
            include_once 'inc/all_hostels.php';
          }

          ?>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      

<?php include_once 'foot.php'; ?>