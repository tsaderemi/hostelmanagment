<?php
require_once '../config/config.php'; 
  
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  
  $page_title = "Admin Dashboard";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      
      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include_once 'top-nav.php'; ?>
        <!-- End of Topbar -->
        
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <section class="content-header">
          <h1>
            <?php echo $page_title; ?>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li class="active"><?php echo $page_title; ?></li>
          </ol>
        </section>
          
          <div class="row">
              
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color: #4e73df">Total Hostel Block</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">46</div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Female Hostel</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">26</div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>             
                  </div>
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Female Hostel</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">20</div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Number of Rooms</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(25543); ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            </div>
          <!-- Content Row -->
          
          
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color: #4e73df">Total Number of Student</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(45765); ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Number of Application</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo number_format(20534); ?></div>
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Approved Application</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(15887); ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Occupied Rooms</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(15763); ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          <div class="row">
            
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1" style="color: #4e73df">Vacant Rooms</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(15763); ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-sort-up fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Faulty Rooms</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">43</div>
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-money-check fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          
          <!-- Content Row -->
          <!--
          <div class="row">
            
            <div class="col-lg-6">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Announcement</h6>
                </div>
                <div class="card-body">
                    <p>Dear Customer,<br>
          MTN Data Share service has been fully restored and all pending transactions have been resolved!<br>
          <br>
          Thanks for choosing safetopup.<br>
          <br>
          <br>
          <br>
          </p>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Become A Portal Owner</h6>
                </div>
                <div class="card-body">
                    <p style="color: #000">
                        You too can have your own VTU Web Portal like 
                        <b style="color: blue">mtndatashop.com</b> <br>
                        This enables you to manage your own customer base. 
                        Your clients can directly register under you and start selling directly from your website.<br>
                        <br><font color="red">For more details, please call: Admin on 08138311449</font>
                    </p>
                </div>
              </div>
            </div>
            
          </div>
            
          
            
        <div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Last 10 Transactions</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                                                <table class="table table-hover table-bordered table-striped">
                            <tbody><tr>
                                <td>#</td>
                                <td>Date</td>
                                <td>Product</td>
                                <td>Old Balance</td>
                                <td>Amount Charged</td>
                                <td>New Balance</td>
                                <td>Status</td>
                            </tr>
                            <tr>
                                                        
                        </tr></tbody></table>
                    </div>
                        <div align="center" style="margin-bottom: 5%">
                            <a href="transacts" class="btn btn-lg btn-primary"> <b>View All Transactions</b></a>
                        </div>
                    
                </div>
              </div>
            </div>
            
        </div>
      -->

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      

<?php include_once 'foot.php'; ?>