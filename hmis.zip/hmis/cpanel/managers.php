<?php
require_once '../config/config.php'; 
  /*
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  */
  $page_title = "Hostel Managers";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
<?php
if(isset($_POST["ok-add"])){
    $userid = mysqli_real_escape_string($conn,$_POST["userid"]);
    $username = mysqli_real_escape_string($conn,$_POST["username"]);
    $managersname = mysqli_real_escape_string($conn,$_POST["managersname"]);
    $role = mysqli_real_escape_string($conn,$_POST["role"]);
    $hostelname = mysqli_real_escape_string($conn,$_POST["hostelname"]);
    $password = mysqli_real_escape_string($conn,$_POST["password"]);
    $password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT into hostel_managers (userid,name,username,password,role,hostel) values ('$userid','$managersname','$username','$password','$role','$hostelname')";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));

    if($result === TRUE){
      set_flash("New hostel manager added successfully","success");
    }else{
      set_flash("There was error in adding new manager","danger");
    }
  }
if(isset($_POST["ok-update"])){
  $userid = mysqli_real_escape_string($conn,$_POST["userid"]);
    $role = mysqli_real_escape_string($conn,$_POST["role"]);
    $hostelname = mysqli_real_escape_string($conn,$_POST["hostelname"]);
    $password = mysqli_real_escape_string($conn,$_POST["password"]);
    $password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "UPDATE hostel_managers set role = '$role', hostel = '$hostelname', password = '$password' where userid = '$userid' ";
    $result = $conn->query($sql)or
    die(mysqli_error($conn));

    if($result === TRUE){
      set_flash("Managers information updated successfully","success");
    }else{
      set_flash("There was in updating managers information","danger");
    }

}
?>
      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include_once 'top-nav.php'; ?>
        <!-- End of Topbar -->
        
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        <section class="content-header">
          <h1>
            <?php echo $page_title; ?>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li class="active"><?php echo $page_title; ?></li>
          </ol>
        </section>
          <!-- Content Row -->
          <?php 
          if(isset($_GET["act"])){
            switch ($_GET["act"]) {
              case 'view':
                include_once 'inc/view_managers.php';
                break;

              case 'add':
                include_once 'inc/add_manager.php';
                break;

              case 'edit':
                include_once 'inc/edit_manager.php';
                break;


              default:
                # code...
                break;
            }
          }else{
            include_once 'inc/all_managers.php';
          }

          ?>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      

<?php include_once 'foot.php'; ?>