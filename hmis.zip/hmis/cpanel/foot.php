<!-- Footer -->
        <!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Thanks for using our services. We hope to see you soon.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Keep Using Service</button>
          <a class="btn btn-primary" href="logout">Logout</a>
        </div>
      </div>
    </div>
</div>
<footer class="sticky-footer" style="background: #000; color: #fff">
    
    <div class="container my-auto">
        <div class="copyright text-left my-auto">
            <span style="font-size: 13px"><b>Copyright FPE &copy; <?php echo date("Y"); ?> - All rights reserved.  </b></span>
            <span class="text-right" style="float: right;"><?php echo site_name(); ?>.</span>
        </div>
      </div>
</footer>      <!-- End of Footer -->

</div>
    <!-- End of Content Wrapper -->

  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
    <i class="fa fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

  <script type="text/javascript">
  $(document).ready(function() {
    $('#tables').DataTable();



        $("#c_all").click(function(e) {
           var a = $(this).prop("checked");
           $(".cbox").prop("checked",a);
        });

        $(".btn-delete-cats").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete this category \n(All questions will be deleted)?");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });


        $(".btn-delete-question").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete this question?");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });

        $(".btn-ok-access").click(function(event){
          var a = confirm("Are you sure you want to grant access to this student's result?");
          if(a == false){
            event.preventDefault();
            return false;
          }
        })


        $(".btn-ok-all-access").click(function(event){
          var a = confirm("Are you sure you want to grant access to the student's result selected?");
          if(a == false){
            event.preventDefault();
            return false;
          }
        })

        $(".btn-delete-result").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete the selected results??");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });

        //btn-delete-result


  });
</script>
<script>
  if(window.history.replaceState) {
     window.history.replaceState(null, null, window.location.href);
  }
</script>

</body>
</html>