<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Faulty Rooms</h6>
                  <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
                  <a class="btn btn-sm btn-success" href="rooms?act=add">Add New Room <i class="fa fa-plus"></i></a>
                <?php
              }
              ?>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-striped" id="dataTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Room Id</th>
                                    <th>Hostel Block</th>
                                    <th>Room Number</th>
                                    <th>Capacity</th>
                                    <th>Space Occupied</th>
                                    <th>Space Free</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                              $sql = "SELECT * from hostel_rooms where conditions = 0 order by id asc ";
                              $result = $conn->query($sql)or
                              die(mysqli_error($conn));
                              if($result->num_rows > 0){
                                $sn = "";
                                while($rs = $result->fetch_assoc()){
                                  $hostelid = $rs["hostel_id"];
                                  $capacity = $rs["capacity"];
                                  $occupied = $rs["num_occupy"];
                                  $free = $rs["capacity"]-$occupied;
                              ?>
                                <tr>
                                   <td><?php echo ++$sn; ?></td>
                                   <td><?php echo $rs["room_id"]; ?></td> 
                                   <td>
                                     <?php
                                      $hblock  = "SELECT * from hostel_names where hostel_id = '$hostelid' ";
                                      $hblockRes = $conn->query($hblock)or
                                      die(mysqli_error($conn));
                                      $hblockRs = $hblockRes->fetch_assoc();

                                      echo $hblockRs["block_name"];
                                     ?>
                                   </td>
                                   <td>Room <?php echo $rs["room_number"]; ?></td>
                                   <td><?php echo $rs["capacity"]; ?></td>
                                   <td><?php echo $rs["num_occupy"]; ?></td>
                                   <td><?php echo $rs["capacity"]-$rs["num_occupy"]; ?></td>
                                   <td>
                                     <?php
                                     $status = $rs["status"];
                                     if($status == 2){
                                    ?>
                                    <span class="btn btn-success btn-sm">Empty</span>
                                    <?php
                                     }else if($status == 1){
                                    ?>
                                    <span class="btn btn-warning btn-sm">Free</span>
                                    <?php
                                     }else if($status == 0){
                                    ?>
                                    <span class="btn btn-danger btn-sm">Occupied</span>
                                    <?php
                                     }
                                     ?>
                                   </td>                                   
                                </tr>
                              <?php
                                }
                              }
                              ?>
                            </tbody>
                        </table>
                    </div>                                            
                </div>
              </div>
            </div>
            
        </div>