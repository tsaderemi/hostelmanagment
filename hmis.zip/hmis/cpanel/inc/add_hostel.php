
    <div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add Hostel</h6>
                  <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
                  <a class="btn btn-sm btn-success" href="hostels?act=add">Add New Hostel <i class="fa fa-plus"></i></a>
            <?php
                }
            ?>
                </div>
                <div class="card-body">
                <?php echo flash(); ?>                       
                            <form method="post">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>Hostel Id: </b></label>
                                        <input class="form-control" name="hostelid" id="fname" value="<?php echo($roomId) ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Hostel Name: </b></label>
                                        <input class="form-control" name="hname" id="" value="" type="text" required="">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Hostel Block Name: </b></label>
                                        <input class="form-control" value="" placeholder="Example A11" name="block" required="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Number of Rooms: </b></label>
                                        <input class="form-control" name="noroom" type="number" id="noroom">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Capacity Per Room: </b></label>
                                        <input class="form-control" name="capacity" type="number" id="capacity" required="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Total Capacity: </b></label>
                                        <input class="form-control" name="totcapacity" type="number" value="" readonly="" id="totcapacity">
                                    </div>
                                </div>
                                
                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-12">
                                        <label><b>Hostel Category: </b></label>
                                        <select class="form-control" name="category" required="">
                                            <option></option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div style="margin-top: 3%" align="center">
                                    <button class="btn btn-primary" type="submit" name="ok-add">
                                        <b><i class="fa fa-check"></i> Add Hostel</b>
                                    </button><br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>
            
        </div>
        <script>
            $(document).ready(function(){
                $("#capacity").keyup(function(){
                    var capacity = $(this).val();
                    var noroom = $("#noroom").val();
                    var total = (capacity * noroom);
                    $("#totcapacity").val(total);                    
                })
            });
        </script>