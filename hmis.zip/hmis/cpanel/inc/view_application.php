  <div class="row">
  <?php
  if(isset($_GET["act"])){
    $id = $_GET["id"];
  }



  $sql = "SELECT * from hostel_application where id = '$id' ";
  $result = $conn->query($sql)or
  die(mysqli_error($conn));

  $rs = $result->fetch_assoc();
  $hostelid = $rs["hostel_id"];
  $status = $rs["status"];
  $userid = $rs["userid"];
  ?>
      <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Application Info</h6>
                </div>
                <div class="card-body">
                            <?php flash(); ?>                      
                            
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>Application Id: </b></label>
                                        <input class="form-control" name="userid" id="userid" value="<?php echo($id); ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Student Id: </b></label>
                                        <input class="form-control" name="managersname" id="" required="" readonly="" value="<?php echo($rs["userid"]); ?>">
                                    </div>
                                </div>
                                
                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Hostel Applied:</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo view_hostel($conn,$hostelid); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Room Applied: </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="Room <?php echo($rs["room_no"]); ?>">
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Application Status </b></label>
                                        <span class="form-control btn btn-<?php echo(btcClass($status)); ?>"><?php if ($status == 1) {echo "Approved <i class='fa fa-check'></i>";}elseif($status == 0) {echo "Pending <i class='fa fa-hourglass-half'></i>";} ?></span>
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Application Date</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo $rs["date_applied"]; ?>">
                                    </div>
                                </div>                                
                                <br>
                            
                            <div class="card-header adj-padding">
                              Hostel Fee Status
                            </div>
                            <?php
                            $fee = "SELECT hostel_fee.payment, hostel_fee.userid, hostel_fee.status, hostel_fee.others, hostel_students.gender as gender from hostel_fee inner join hostel_students on hostel_fee.userid = hostel_students.userid where hostel_fee.userid = '$userid' ";
                            $feeRes = $conn->query($fee)or
                            die(mysqli_error($conn));
                            $feeRs = $feeRes->fetch_assoc();
                            $status = $feeRs["status"];
                            $gender = $feeRs["gender"];
                            ?>
                            <div class="row" style="margin-top: 1%">
                                <div class="col-md-6">
                                    <label><b>Student Id </b></label>
                                    <input class="form-control" name="" required="" readonly="" value="<?php echo($feeRs["userid"]); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label><b>Hostel Payment Amount</b></label>
                                    <input type="text" class="form-control" name="" readonly="" value="&#8358; <?php echo number_format($feeRs["payment"],2); ?>">
                                </div>
                            </div>
                            <div class="row" style="margin-top: 1%">
                                <div class="col-md-6">
                                    <label><b>Hostel fee Status </b></label>
                                    <span class="form-control btn btn-<?php echo(btcClassFee($status)); ?>"><?php if ($status == 1) {echo "Paid <i class='fa fa-check'></i>";}elseif($status == 0) {echo "Not Paid <i class='fa fa-times'></i>";} ?></span>
                                </div>
                                <div class="col-md-6">
                                    <label><b>Application Date</b></label>
                                    <input type="text" class="form-control" name="" readonly="" value="<?php echo $rs["date_applied"]; ?>">
                                </div>
                                <div class="col-md-12">
                                    <label><b>Other Fees</b></label>
                                    <input type="text" class="form-control" name="" readonly="" value="&#8358; <?php echo number_format($feeRs["others"],2); ?>">
                                </div>
                            </div>
                            <br>
                            <div class="card-header adj-padding" id="processing">
                              Hostel Allocation Processing
                            </div>
                            <form class="form" id="" action="" method="post">

                              <div class="row" style="margin-top: 1%">
                                <div class="col-md-6">
                                  <label><b>Hostel to Allocate</b></label>
                                  <select class="form-control" name="hostels" required="" id="disHostels">
                                    <option>Select Hostel...</option>
                                    <?php echo allocate_hostel($conn,$gender); ?>
                                  </select>
                                  
                                </div>

                                <div class="col-md-6">
                                  <label><b>Room to Allocate</b></label>
                                  <select class="form-control" name="rooms" required="" id="displayRooms">
                                    
                                  </select>
                                </div>
                              </div>
                              <div class="row" style="margin-top: 1%">
                                <div class="col-md-12">
                                  <label><b>Avaialbel Space In Room</b></label>
                                  <input type="text" class="form-control" id="displayRoomInfo" name="" readonly="">
                                </div>
                                <div class="col-md-12">
                                  <input type="hidden" class="form-control" name="userid" readonly="" value="<?php echo($feeRs["userid"]); ?>">
                                </div>
                              </div>
                              <div style="margin-top: 3%" align="center">
                                    <?php
                                    if($rs["status"] == 1){
                                    ?>
                                    <button class="btn btn-success" type="button" disabled="">
                                        <b>Allocate Room <i class="fa fa-fw fa-check"></i></b>
                                    </button><br><br><br>
                                    <?php
                                    }else if($feeRs["status"] == 0){
                                    ?>
                                    <button class="btn btn-danger" type="button" disabled="">
                                        <b>Allocate Room <i class="fa fa-fw fa-check"></i></b>
                                    </button><br><br><br>
                                    <?php
                                    }else{
                                    ?>
                                    <button class="btn btn-primary" type="submit" name="ok-allocate">
                                        <b>Allocate Room <i class="fa fa-fw fa-check"></i></b>
                                    </button><br><br><br>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </form>
                        </div>
              </div>
            </div>      
            
  </div>
  <script type="text/javascript">
    $(document).ready(function(){

      $("#disHostels").on("change", function(){
          var hostelId = $(this).val();
          if(hostelId == 'Select Hostel..'){
            $("#displayRooms").html('');
          }else{
            $.ajax({
              url: "ajax.php?getRooms",
              type: "POST",
              data: {
                hostelid: hostelId
              },
              success: function(results){
                $("#displayRooms").html(results);
              },
            });
          }
        });

      $("#displayRooms").on("change", function(){
        var roomId = $(this).val();
        if(roomId == ''){
          $("#displayRoomInfo").val('');
        }else{
            $.ajax({
              url: "ajax.php?getRoomInfo",
              type: "POST",
              data: {
                roomid: roomId
              },
              success: function(results){
                $("#displayRoomInfo").val(results);
              },
            });
          }
      })
      
    });
  </script>