<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View/Edit/Delete Hostel</h6>
                  <a class="btn btn-sm btn-success" href="admin?act=add">Add New Admin <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-striped" id="dataTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Product</th>
                                    <th>Old Balance</th>
                                    <th>Amount Charged</th>
                                    <th>New Balance</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                              $sql = "SELECT * from hostel_names order by id desc ";
                              $result = $conn->query($sql)or
                              die(mysqli_error($conn));
                              if($result->num_rows > 0){
                                $sn = "";
                                while($rs = $result->fetch_assoc()){
                              ?>
                                <tr>
                                   <td>1</td>
                                   <td>gdkgf</td> 
                                   <td>sdjkhkhdf</td>
                                   <td>iudkfh</td>
                                   <td>jkdshfh</td>
                                   <td>98owejw</td>
                                   <td>ikdjsf</td>
                                   <td><a class="btn btn-primary btn-sm" href="students?act=view">View <i class="fa fa-eye"></i></a></td>
                                </tr>
                              <?php
                                }
                              }
                              ?>
                            </tbody>
                        </table>
                    </div>                                            
                </div>
              </div>
            </div>
            
        </div>