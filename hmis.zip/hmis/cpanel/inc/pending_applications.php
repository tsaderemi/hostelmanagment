<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">All Hostels Applications</h6>                  
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-striped" id="dataTable">
                            <thead class="thead-dark">
                                <tr>
                                  <th>#</th>
                                  <th>User Id</th>
                                  <th>Hostel Name</th>
                                  <th>Room Number</th>
                                  <th>Date Applied</th>
                                  <th>Status</th>
                                  <th>View</th>
                                  <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                              $sql = "SELECT * from hostel_application where status = 0 order by id asc ";
                                $result = $conn->query($sql)or
                                die(mysqli_error($conn));
                                $sn = "";
                                while ($rs = $result->fetch_assoc()){
                                  $status = $rs["status"];
                                  $hostelid = $rs["hostel_id"];
                              ?>
                                <tr>
                                  <td><?php echo ++$sn; ?></td>                                  
                                  <td><?php echo $rs["userid"]; ?></td>
                                  <td>
                                     <?php
                                            $hblock  = "SELECT * from hostel_names where hostel_id = '$hostelid' ";
                                            $hblockRes = $conn->query($hblock)or
                                            die(mysqli_error($conn));
                                            if($hblockRes->num_rows > 0){
                                              $hblockRs = $hblockRes->fetch_assoc();

                                              echo $hblockRs["hostel_name"]." ".$hblockRs["block_name"];
                                            }
                                      ?>
                                  </td>
                                  <td>Room <?php echo $rs["room_no"]; ?></td>
                                  <td><?php echo $rs["date_applied"]; ?></td>
                                  <td>
                                    <?php
                                    if($status == "0"){
                                    ?>
                                      <span class="btn btn-warning btn-sm" href="javascript:void();">Pending <i class="fa fa-hourglass-half"></i></span>
                                    <?php
                                    }else if($status == "1"){
                                    ?>
                                      <span class="btn btn-success btn-sm" href="javascript:void();">Approved <i class="fa fa-check"></i></span>
                                    <?php
                                    }
                                    ?>
                                  </td>
                                  <td><a class="btn btn-primary btn-sm" target="_blank" href="applications.php?act=view&id=<?php echo($rs["id"]); ?>">View <i class="fa fa-eye"></i></a></td>
                                  <td>
                                    <a class="btn btn-danger btn-sm" href="#">Delete <i class="fa fa-trash"></i></a>
                                  </td>                          
                                </tr>
                              <?php
                                }
                              ?>
                            </tbody>
                        </table>
                    </div>                                            
                </div>
              </div>
            </div>
            
        </div>