  <div class="row">
  <?php
  if(isset($_GET["act"])){
    $id = $_GET["id"];
  }



  $sql = "SELECT * from hostel_names where hostel_id = '$id' ";
  $result = $conn->query($sql)or
  die(mysqli_error($conn));

  $rs = $result->fetch_assoc();
  $hostid = $rs["hostel_id"];
  ?>
      <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Hostel Profile</h6>
                  <?php
                  if($_SESSION["admin_role"] == "admin"){
                  ?>
                  <a class="btn btn-sm btn-success" href="hostels?act=add"><i class="fa fa-plus"></i> Add New Hostel</a>
                  <?php
                    }
                  ?>
                </div>
                <div class="card-body">
                            <?php flash(); ?>                      
                            <form method="post" action="">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>Hostel Id: </b></label>
                                        <input class="form-control" name="userid" id="userid" value="<?php echo($id); ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Hostel Name: </b></label>
                                        <input class="form-control" name="managersname" id="" required="" readonly="" value="<?php echo($rs["hostel_name"]); ?>">
                                    </div>
                                </div>
                                
                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Block:</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["block_name"]); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Hostel Category: </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["hostel_category"]); ?>">
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Total Rooms </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["total_rooms"]); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Available Rooms</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo available_rooms($conn,$hostid); ?>">
                                    </div>
                                </div>
                                
                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Capacity Per Room:</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["capacity_per_room"]); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Total Capacity: </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["capacity"]); ?>">
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Manager In Charge:</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo hostel_manager($conn,$id); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Date Created: </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["date_created"]); ?>">
                                    </div>
                                </div>
                                
                                <div style="margin-top: 3%" align="center">
                                    <br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>      
            
  </div>