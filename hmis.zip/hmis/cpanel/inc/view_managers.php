  <div class="row">
  <?php
  if(isset($_GET["act"])){
    $id = $_GET["id"];
  }



  $sql = "SELECT * from hostel_managers where userid = '$id' ";
  $result = $conn->query($sql)or
  die(mysqli_error($conn));

  $rs = $result->fetch_assoc();
  $hostid = $rs["hostel"];
  ?>
      <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Manager Profile</h6>
                  <a class="btn btn-sm btn-success" href="managers?act=add"><i class="fa fa-plus"></i> Add New Hostel Manager</a>
                </div>
                <div class="card-body">
                            <?php flash(); ?>                      
                            <form method="post" action="">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>User Id: </b></label>
                                        <input class="form-control" name="userid" id="userid" value="<?php echo($id); ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Managers Name: </b></label>
                                        <input class="form-control" name="managersname" id="" required="" readonly="" value="<?php echo($rs["name"]); ?>">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Hostel in Charge (Block)</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo(hostel_assign($conn,$hostid)); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Managers Role </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["role"]); ?>">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Managers Username:</b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["username"]); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Date Created: </b></label>
                                        <input type="text" class="form-control" name="" readonly="" value="<?php echo($rs["date_created"]); ?>">
                                    </div>
                                </div>
                                
                                <div style="margin-top: 3%" align="center">
                                    <br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>      
            
  </div>