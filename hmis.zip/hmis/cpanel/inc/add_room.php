<?php
?>    
    <div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add Room</h6>
                  <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
                  <a class="btn btn-sm btn-success" href="rooms.php?act=add">Add New Room <i class="fa fa-plus"></i></a>
                <?php
                    }
                ?>
                </div>
                <div class="card-body">
                                                        
                            <form method="post">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>Room Id: </b></label>
                                        <input class="form-control" name="hostelid" id="fname" value="<?php echo($roomId) ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Room Number: </b></label>
                                        <input class="form-control" name="hname" id="lname" value="" type="text" required="">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Hostel Block: </b></label>
                                        <input class="form-control" value="" name="block" required="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Capacity: </b></label>
                                        <input class="form-control" name="noroom" type="number" id="noroom">
                                    </div>
                                </div>
                                
                                <div style="margin-top: 3%" align="center">
                                    <button class="btn btn-primary" name="updateAccnt">
                                        <b>Add Room <i class="fa fa-check"></i></b>
                                    </button><br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>
            
        </div>
        <script>
            $(document).ready(function(){
                $("#capacity").keyup(function(){
                    var capacity = $(this).val();
                    var noroom = $("#noroom").val();
                    var total = (capacity * noroom);
                    $("#totcapacity").val(total);                    
                })
            });
        </script>