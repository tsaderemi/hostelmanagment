<?php
function createId($qtd){
    $Caracteres = '23456789';
    $QuantidadeCaracteres = strlen($Caracteres);
    $QuantidadeCaracteres--;
    $Hash=NULL;
    for($x=1; $x<=$qtd; $x++){
        $Posicao = rand(0,$QuantidadeCaracteres);
        $Hash .= substr($Caracteres,$Posicao,1);
    }
    return $Hash;
}
$formid =  createId(4);

?>    
<div class="row">
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add New Manager</h6>
                  <a class="btn btn-sm btn-success" href="managers?act=add">Add New Hostel Manager <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                            <?php flash(); ?>                      
                            <form method="post" action="">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>User Id: </b></label>
                                        <input class="form-control" name="userid" id="userid" value="<?php echo($formid); ?>" readonly="">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Name: </b></label>
                                        <input class="form-control" name="managersname" id="" required="">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Hostel Name </b></label>
                                        <select class="form-control" name="hostelname" required="">
                                            <option></option>
                                            <?php hostel_names($conn); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Role </b></label>
                                        <select class="form-control" required="" name="role">
                                            <option></option>
                                            <option>Manager</option>
                                        </select>
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Username:</b></label>
                                        <input class="form-control" value="" name="username" required="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Password: </b></label>
                                        <input class="form-control" value="" name="password" type="password" placeholder="******">
                                    </div>
                                </div>
                                
                                <div style="margin-top: 3%" align="center">
                                    <button class="btn btn-primary" name="ok-add" type="submit" >
                                        <b>Create Manager <i class="fa fa-check"></i></b>
                                    </button><br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>
            
        </div>