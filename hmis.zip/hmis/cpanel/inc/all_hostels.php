<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">All Hostels</h6>
                  <?php
            if($_SESSION['admin_role'] === "admin"){
            ?>
                  <a class="btn btn-sm btn-success" href="hostels?act=add">Add New Hostel <i class="fa fa-plus"></i></a>
            <?php
              }
            ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-striped" id="dataTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <!--<th>Id</th>-->
                                    <th>Name</th>
                                    <th>Block</th>
                                    <th>Rooms</th>
                                    <th>Available</th>
                                    <th>Per Room</th>
                                    <th>Capacity</th>
                                    <th>Category</th>
                                    <th>View</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                              $sql = "SELECT * from hostel_names order by id asc ";
                              $result = $conn->query($sql)or
                              die(mysqli_error($conn));
                              if($result->num_rows > 0){
                                $sn = "";
                                while($rs = $result->fetch_assoc()){
                                  $hostid = $rs["hostel_id"];
                              ?>
                                <tr>
                                  <td><?php echo ++$sn; ?></td>
                                  <!--<td><?php //echo $rs["hostel_id"]; ?></td>-->
                                  <td><?php echo $rs["hostel_name"]; ?></td>
                                  <td><?php echo $rs["block_name"]; ?></td>
                                  <td><?php echo $rs["total_rooms"]; ?></td>
                                  <td><?php echo available_rooms($conn,$hostid); ?></td>
                                  <td><?php echo $rs["capacity_per_room"]; ?></td>
                                  <td><?php echo $rs["capacity"]; ?></td>
                                  <td><?php echo $rs["hostel_category"]; ?></td>
                                  <td><a class="btn btn-primary btn-sm" href="hostels.php?act=view&id=<?php echo($rs["hostel_id"]); ?>">View <i class="fa fa-eye"></i></a></td>
                                  <td><a class="btn btn-info btn-sm" href="hostels.php?act=edit&id=<?php echo($rs["hostel_id"]); ?>">Edit <i class="fa fa-edit"></i></a></td>
                                  <td>
                                    <a class="btn btn-danger btn-sm" href="#">Delete <i class="fa fa-trash"></i></a>
                                  </td>
                                </tr>
                              <?php
                                }
                              }
                              ?>
                            </tbody>
                        </table>
                    </div>                                            
                </div>
              </div>
            </div>
            
        </div>