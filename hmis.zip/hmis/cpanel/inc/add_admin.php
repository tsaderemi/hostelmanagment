<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add Hostel Admin</h6>
                  <a class="btn btn-sm btn-success" href="admin?act=add">Add New Admin <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                                                        
                            <form method="post">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <label for="fname"><b>First Name: </b></label>
                                        <input class="form-control" name="fname" id="fname" value="Taiwo">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="lname"><b>Last Name: </b></label>
                                        <input class="form-control" name="lname" id="lname" value="Sarafa">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Email Address: </b></label>
                                        <input class="form-control" value="aderemi.s641@gmail.com" disabled="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Mobile Number: </b></label>
                                        <input class="form-control" value="08030891417" disabled="">
                                    </div>
                                </div>
                                
                                 <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Current Plan: <a href="https://mtndatashop.com/olastech/upgrade-plan" style="color: red">Upgrade Plan</a></b></label>
                                        <input class="form-control" value="Starter" disabled="">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Wallet Balance: </b></label>
                                        <input class="form-control" value="₦0.00" disabled="">
                                    </div>
                                </div>
                                
                                <div class="row" style="margin-top: 1%">
                                    <div class="col-md-6">
                                        <label><b>Web Hook: <i>(Leave empty if none)</i></b></label>
                                        <input class="form-control" value="" name="webhook" placeholder="Enter webhook url">
                                    </div>
                                    <div class="col-md-6">
                                        <label><b>Transaction Pin: </b></label>
                                        <input class="form-control" value="" name="pin" placeholder="Enter transaction pin">
                                    </div>
                                </div>
                                
                                
                                <div style="margin-top: 3%" align="center">
                                    <button class="btn btn-primary" name="updateAccnt">
                                        <b>Update Account</b>
                                    </button><br><br><br>
                                </div>
                            </form>
                            
                        </div>
              </div>
            </div>
            
        </div>