<?php
?>    
        <div class="row">
             
            <div class="col-lg-12">
                <?php echo flash(); ?>
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Vercate Room</h6>
                </div>
                <div class="card-body">                                                        
                    <form method="post">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="fname"><b>Matric Number:</b></label>
                                <input class="form-control" name="matric" id="" value="<?php echo(@$_POST["matric"]);?>" required="">
                            </div>                            
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="fname"><b>Hostel Id:</b></label>
                                <input class="form-control" name="hostelid" id="" value="<?php echo(@$_POST["hostelid"]);?>" required="">
                            </div>
                            <div class="col-md-6">
                                <label for="fname"><b>Room Id:</b></label>
                                <input class="form-control" name="roomid" id="" value="<?php echo(@$_POST["roomid"]);?>" required="">
                            </div>
                        </div>
                                
                        <div style="margin-top: 3%" align="center">
                            <button class="btn btn-primary" name="vercate">
                                <b>Vercate Room <i class="fa fa-check"></i></b>
                            </button><br><br><br>
                        </div>
                    </form>                        
                </div>
              </div>
            </div>
            
        </div>
        <script>
            $(document).ready(function(){
                $("#capacity").keyup(function(){
                    var capacity = $(this).val();
                    var noroom = $("#noroom").val();
                    var total = (capacity * noroom);
                    $("#totcapacity").val(total);                    
                })
            });
        </script>