<div class="row">
            
            <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">All Hostel Managers</h6>
                  <a class="btn btn-sm btn-success" href="managers?act=add">Add New Hostel Manager <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-striped" id="dataTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>User Id</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Hostel In Charge</th>
                                    <th>View</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php
                              $sql = "SELECT * from hostel_managers order by id desc ";
                              $result = $conn->query($sql)or
                              die(mysqli_error($conn));
                              if($result->num_rows > 0){
                                $sn = "";
                                while($rs = $result->fetch_assoc()){
                                  $hostid = $rs["hostel"];
                              ?>
                                <tr>
                                  <td><?php echo ++$sn; ?></td>
                                  <td><?php echo $rs["userid"]; ?></td> 
                                  <td><?php echo $rs["name"]; ?></td>
                                  <td><?php echo $rs["username"]; ?></td>
                                  <td><?php echo $rs["role"]; ?></td>
                                  <td><?php echo hostel_assign($conn,$hostid); ?></td>
                                  <td><a class="btn btn-primary btn-sm" href="managers.php?act=view&id=<?php echo($rs["userid"]); ?>">View <i class="fa fa-eye"></i></a></td>
                                  <td><a class="btn btn-info btn-sm" href="managers.php?act=edit&id=<?php echo($rs["userid"]); ?>">Edit <i class="fa fa-edit"></i></a></td>
                                  <td>
                                    <a class="btn btn-danger btn-sm" href="#">Delete <i class="fa fa-trash"></i></a>
                                  </td>
                                </tr>
                              <?php
                                }
                              }
                              ?>
                            </tbody>
                        </table>
                    </div>                                            
                </div>
              </div>
            </div>
            
        </div>