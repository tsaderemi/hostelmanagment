<?php
	session_start();
	unset($_SESSION['admin']);
	unset($_SESSION['admin_name']);
	
	if($_SESSION["admin_role"] == "Manager"){
		unset($_SESSION['admin_role']);
		header("location: ../hostel_manager");
	}else{
		unset($_SESSION['admin_role']);
		header("location: login");
	}
	
	exit();
?>