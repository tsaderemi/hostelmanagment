<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <title>Login | Admin</title>

  <!-- Favicons -->
  <link href="assets/img/icon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../dashboard/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../dashboard/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/msc-style.css">
  <!-- Custom styles for this template -->
  <link href="../dashboard/css/style.css" rel="stylesheet">
  <link href="../dashboard/css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style-demo.css">

  <script src="../dashboard/lib/jquery/jquery.min.js"></script>
  <style>
    .over-lay{
      content: "";
      position: absolute;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.6);
      background-image: url('../images/logo2fade.png') !important;
      background-size: 20%;
      z-index: 1;
    }
    .login-page{
      position: 
      z-index: 10;
    }
    .panel-body{
      background-image: url('../images/logo2fade.png') !important;
      background-size: 20%;
    }
  </style>
</head>

<body>
<div class="over-lay">
<?php
require_once '../config/config.php';
if(isset($_POST["ok"])){
  $username = mysqli_real_escape_string($conn,($_POST["username"]));
  $password = mysqli_real_escape_string($conn,($_POST["password"]));
  
  $sql = "SELECT * from hostel_admin where username = '$username' ";
  
  $result = $conn->query($sql)or
  die(mysqli_error($conn));
  if($result->num_rows > 0){

    $rs = $result->fetch_assoc();
    if(password_verify($password, $rs["password"])){
    $id = $rs['id'];
    $_SESSION['admin'] = $id;
    $_SESSION['admin_name'] = $rs['name'];
    $_SESSION['admin_role'] = $rs['role'];      
    
    header("location:index.php");
    exit();
      
    }else{
        set_flash("Invalid username or password","danger");
    }
  }else{
      set_flash("Invalid username or password","danger");
  }
}
?>
  <!-- Site wrapper -->
    <div class="container" style='margin-top: 45px;'>
      <div class="row">
        <div class="col-md-6 col-md-offset-3">
        <div class="main-bg panel panel-default">
          <div class="panel-heading bg-blue text-white">
            <i class="fa fa-lock"></i> Admin Login
          </div>
          <div class="panel-body">
            <form action="" method="post" role='form' class="has-success">
              <h3 class="page-header">Admin Login</h3>
              <?php flash() ?>
              <div class="form-group">
                <label>Username</label>
                <div class="input-group">
                  <input type="text" name="username" required="" class="form-control" placeholder="Username" value="<?php echo @$_POST['username']; ?>">
                  <span class="input-group-addon"><i class="fa fa-user"></i></span>
                </div>
              </div>

              <div class="form-group">
                <label>Password</label>
                <div class="input-group">
                  <input type="password" name="password" required="" class="form-control" placeholder="Password">
                  <span class="input-group-addon"><i class="fa fa-key"></i></span>
                </div>
              </div>              

              <div class="form-group">
                <button class="btn btn-primary" type="submit" name="ok">Login <i class="fa fa-sign-in"></i></button>
              </div>
            </form>       
          </div>
          <div class="panel-footer">&nbsp;</div>
        </div>
      </div>
      </div>
    </div>
</div>
  <!-- js placed at the end of the document so the pages load faster -->
  
  <script src="../dashboard/lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="../dashboard/lib/jquery.backstretch.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $("body").backstretch([
        "../images/2.png",
        "../images/3.png",
        "../images/a.jpg",
        "../images/cover3.jpg",
        "../images/cover4.jpg",
      ], {duration: 5000, fade: 500});
    });
</script>

</body>

</html>
