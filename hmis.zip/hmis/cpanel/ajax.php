<?php
require_once '../config/config.php';

	if(isset($_GET["getRooms"])){

	$hostelid = $_POST["hostelid"];
	
	$sql = "SELECT * from hostel_rooms where hostel_id = '$hostelid' and (status = 1 or status =2) ";

	
	$result = $conn->query($sql)or
	die(mysqli_error($conn));

  if($result->num_rows>0){
     echo "<option value=''>Select Room...</option>";
     while($rs= $result->fetch_assoc())
     {
        echo "<option value='".$rs['id']."'>Room ".$rs['room_number']."</option>";
        
      }
   }  
 }

 if(isset($_GET["getRoomInfo"])){

	$roomid = $_POST["roomid"];
	
	$sql = "SELECT * from hostel_rooms where id = '$roomid' ";
	$result = $conn->query($sql)or
	die(mysqli_error($conn));

  if($result->num_rows>0){
     $rs = $result->fetch_assoc();
     $capacity = $rs["capacity"];
     $occupy = $rs["num_occupy"];

     $left = $capacity - $occupy;

     echo $left;
 }
}


?>