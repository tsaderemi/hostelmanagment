<!DOCTYPE html>
<!-- saved from url=(0046)https://mtndatashop.com/olastech/airtime_topup -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Airtime Topup</title>

  <!-- Custom fonts for this template-->
  <link href="./Airtime Topup_files/all.min.css" rel="stylesheet" type="text/css">
  <link href="./Airtime Topup_files/css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="./Airtime Topup_files/sb-admin-2.min.css" rel="stylesheet">
  
    <link rel="shortcut icon" href="https://mtndatashop.com/olastech/a">
    <link href="./Airtime Topup_files/hydrogenblue.css" rel="stylesheet">
  <script src="./Airtime Topup_files/jquery-2.2.3.min.js.download"></script>
  <script src="./Airtime Topup_files/vtutop.js.download"></script>
  <script>
        function getNetwork() {
            var mobileNo = $("#mobileno").val();
            var networkType = $("#networkType");
            if(mobileNo == '' || mobileNo.length<4) {
                networkType.html('');
            } else {
                $.ajax({
                    url: "ajax.php?getNetworkCode",
                    type: "post",
                    data: "mobileNo="+mobileNo,
                    beforeSend: function(){
                        networkType.html("Getting network....");
                    },
                    success: function(result) {
                        networkType.html(result);
                    }
                })
            }
            
            
        }
  </script>
<link id="avast_os_ext_custom_font" href="chrome-extension://eofcbnmajmjmplflapaojjnihcjkigck/common/ui/fonts/fonts.css" rel="stylesheet" type="text/css"></head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
 
    
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="https://mtndatashop.com/olastech/dashboard">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-signal"></i>
        </div>
        <div class="sidebar-brand-text mx-3"> Zeezmobile.com</div>
      </a>
      
      <hr class="sidebar-divider my-0">
        <p style="margin: 7%; color: #fff">
            <b>Referral Comm: <br> ₦0.00</b>
        </p>
        
              <li class="nav-item ">
        <a class="nav-link" href="https://mtndatashop.com/olastech/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
             
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/news">
          <i class="fas fa-fw fa-bullhorn"></i>
          <span>News Board</span></a>
      </li>
        
        <li class="nav-item" style="display: none">
            <a class="nav-link collapsed" href="https://mtndatashop.com/olastech/airtime_topup#" data-toggle="collapse" data-target="#servCent" aria-expanded="true" aria-controls="wallet">
              <i class="fas fa-fw fa-user"></i>
              <span>Service Center</span>
            </a>
            <div id="servCent" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="https://mtndatashop.com/olastech/productStatus">Products Status</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/offrecord">Offline Service</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/support">Helpdesk</a>
                <a class="collapse-item" href="https://mtndatashop.com/olastech/members_stats">Portal Guide</a>
                              </div>
            </div>
          </li>
      
      <!-- Divider -->
      <hr class="sidebar-divider">
      
              
      <li class="nav-item">
        <a class="nav-link collapsed" href="https://mtndatashop.com/olastech/airtime_topup#" data-toggle="collapse" data-target="#wallet" aria-expanded="true" aria-controls="wallet">
          <i class="fas fa-fw fa-user"></i>
          <span>My Account</span>
        </a>
        <div id="wallet" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="https://mtndatashop.com/olastech/wallet">Add Money</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/share-money">Share Money</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/convertBonus">Wallet Transfer</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/transacts">All Transactions</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/referral-transaction">Referral Earning</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/priceList">Price List</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/updateProfile">Update Profile</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/change-password">Change Password</a>
            <a class="collapse-item" href="https://mtndatashop.com/olastech/upgrade-plan">Upgrade Plan</a>
                      </div>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/airtime_topup">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Artime Topup</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/mtndata">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>MTN Data Bundle</span></a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="https://mtndatashop.com/olastech/airtime_topup#" data-toggle="modal" data-target="#logoutModal">
          <i class="fas fa-fw fa-unlock"></i>
          <span>Logout</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">


            <!-- Nav Item - Alerts -->
            
            <!-- Nav Item - Messages -->
            
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="https://mtndatashop.com/olastech/airtime_topup#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    Taiwo Sarafa<br>08030891417</span>
                <div class="img rounded-circle">
                    <i class="fa fa-user fa-2x"></i>
                </div>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                
                    <a class="dropdown-item" href="https://mtndatashop.com/olastech/airtime_topup#">
                      <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                      Payment History
                    </a>
                    <a class="dropdown-item" href="https://mtndatashop.com/olastech/airtime_topup#">
                      <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                      Manage Product
                    </a>
                                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="https://mtndatashop.com/olastech/airtime_topup#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Buy Airtime</h1>
            <div id="usrbal">    
    <div class="row">
            
        <div class="col-md-6">
            <div style="background: #fff; color: #000; font-size: 18px; padding: 7px; border-bottom: 3px solid #36b9cc">
            	<b><font color="#36b9cc">Wallet Blc:</font> ₦0.00</b>
            </div>
        </div>
        
        <div class="col-md-6">
            <div style="background: #fff; color: #000; font-size: 18px; padding: 7px; border-bottom: 3px solid #ff0000">
            	<b><font color="#ff0000">Plan Level: </font> <br> Starter            </b></div><b>
        </b></div><b>
    </b></div><b>
</b></div>
          </div>
          
          
            <div class="row">
                <div class="col-md-12">
                                    </div> 
            </div>  

          <!-- Content Row -->
          <div class="row">
            <div class="col-md-12">
                <ul class="nav nav-tabs">
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="https://mtndatashop.com/olastech/airtime_topup#addMoney">Buy Airtime</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="https://mtndatashop.com/olastech/airtime_topup#transHist">Airtime History</a>
                </li>
              </ul>
            
              <!-- Tab panes -->
              <div class="tab-content">
                <div id="addMoney" class="container tab-pane active" onmousemove="chkbtn()"><br>
                    <script> var c9Mobile = 0.00</script><script> var cAirtel = 0.00</script><script> var cGLO = 0.00</script><script> var cMTN = 0.00</script><strong>MTN</strong>: 0.00%  <strong>GLO</strong>: 0.00%  <strong>Airtel</strong>: 0.00%  <strong>9Mobile</strong>: 0.00%                  		<br>
                		<div id="imghere" align="center" style="margin-top: 2%; margin-bottome: 2%;"></div>
                		<br>
                    <form method="post" id="myForm">
                        <div class="col-md-12">
                            <label for="networkName"><b>Select Network:</b></label>
                            <select class="form-control input-sm" name="networkName" id="networkName" autofocus="" required="">
                                <option value="">-- Select Network --</option>
                                <option value="mtn">MTN</option>
                                <option value="glo">GLO</option>
                                <option value="airtel">Airtel</option>
                                <option value="9mobile">9Mobile</option>
                            </select>
                        </div>
                        <br>
                        
                        <div class="col-md-12">
                            <label for="mobileno"><b>Mobile Number:</b></label>
                            <input name="mobileno" id="mobileno" class="form-control input-sm" type="text" minlength="11" maxlength="11" placeholder="Enter phone number" onkeydown="getNetwork();" onkeyup="getNetwork();" required="">
                        </div>
                        
                        <div id="networkType"></div>
                        
                        <br>
                        <div class="col-md-12">
                            <label for="amount"><b>Enter Amount (₦):</b></label>
                            <input name="airAmnt" id="airAmnt" class="form-control input-sm" type="number" min="10" max="25000" placeholder="Enter amount" required="">
                        </div>
                        
                        <div id="airtime_result"></div>    
                        
                        <br>
                        
                                                    <div class="col-md-12">
                                <label for="amount"><b>Amount to Pay (₦):</b></label>
                                <input class="form-control input-sm" value="0" id="amnts" disabled="">
                                <input value="0" id="amnt" name="amnt" type="hidden">
                            </div>
                                                <!--just for percentage calculation-->
                        <!--
                        <input value="0" id='percent' disabled type="hidden">
                        <!--just for percentage calculation-->
                        
                                                    <br>
                            <font color="red"><b>NOTE: </b></font> Minimum airtime purchase is <font color="red"><b>₦10.00</b></font> and Maximum is <font color="red"><b>₦25,000.00</b></font> 
                                                <br>
                        <button class="btn btn-block btn-lg btn-primary" id="mybtn" type="button" disabled="">
                            <b>Buy Airtime </b>
                        </button> <br><br><br><br><br><br>
                    </form>
                </div>
                <div id="transHist" class="container tab-pane fade"><br>
                
                         <div class="table-responsive">
                            <table class="table table-bordered table-hover dataTable no-footer" id="dataTable" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                    <th>SN</th>
                	                <th>Network</th>
                	                <th>Mobile No</th>
                	                <th>Value</th>
                	                <th>Old Balance</th>
                	                <th>Amount Deducted</th>
                	                <th>New Balance</th>
                	                <th>Cashback</th>
                	                <th>Status</th>
                	                <th>Date</th>
                	                <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                                                            </tr>
                                </tbody>
                              
                            </table><br><br><br>
                          </div>

                </div>
              </div>
            </div>
          </div>

          
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
  <!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Thanks for using our services. We hope to see you soon.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Keep Using Service</button>
          <a class="btn btn-primary" href="https://mtndatashop.com/olastech/logout">Logout</a>
        </div>
      </div>
    </div>
</div>

<div style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;">
    <a href="https://api.whatsapp.com/send?phone=2348138311449&amp;text=I%27ll%20like%20to%20know%20more%20about%20Data%20bundle" target="_blank">
        <img src="./Airtime Topup_files/whatsapp.png" width="90" height="90"></a>
</div>
<footer class="sticky-footer" style="background: #000; color: #fff">
    
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span style="font-size: 24px"><b>©  Zeezmobile.com </b></span>
            
            <div style="margin-top: 10px; font-size: 18px">
                <b>Email: </b><a href="mail:abdulazeezolawalea@gmail.com" style="color: #fff">abdulazeezolawalea@gmail.com</a> || 
                <b>Support: </b> 08138311449            </div>
        </div>
    </div>
</footer>
    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="https://mtndatashop.com/olastech/airtime_topup#page-top">
    <i class="fas fa-angle-up"></i>
  </a>



	<!-- The Modal -->
	<div class="modal" id="modal22">
	  <div class="modal-dialog">
	    <div class="modal-content">

	      <!-- Modal Header -->
	      <div class="modal-header">
	        <h4 class="modal-title">Confirm Transaction</h4>
	        <button type="button" class="close" data-dismiss="modal">×</button>
	      </div>

	      <!-- Modal body -->
	      <div class="modal-body">
		  <h6>Do you want to topup of <span id="networkVal"></span> <del>N</del><span id="airtimevaluelbl"></span> for <span id="recipentlbl"></span>?</h6>

	      </div>

	      <!-- Modal footer -->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			<button type="button" class="btn btn-primary" onclick="confirmation()" data-dismiss="modal">Confirm</button>
	      </div>

	    </div>
	  </div>
	</div>


    <script>
        function calcArit() {
            document.getElementById("networkID").style.display = "";
            document.getElementById("calcArit").style.display = "";
            document.getElementById("networkName").required = true;
        }
        
        function loadNetwork() {
            var networkName = document.getElementById("networkName").value;
            var amnt = getAirValss();
	    
    		var xmlhttp = new XMLHttpRequest();
    		xmlhttp.onreadystatechange = function() {
    			if (this.readyState == 4 && this.status == 200) {
    				document.getElementById("calcArit").innerHTML = this.responseText;
    			}
    		};
    		xmlhttp.open("GET", "aj_airtimecollector?networkName=" + networkName+"&amnt="+amnt, true);
    		xmlhttp.send();
        }
        
        function getAirValss() {
            var amt = document.getElementById("amount").value;
            return amt;
        }
        
        var mybtn = document.getElementById('mybtn');
        mybtn.disabled = true;
        
        function confirmation(){
    	    document.getElementById('myForm').submit();
    	}
    	
    	function chkbtn(){
    		var vendor = document.getElementById('networkName').value;
    		var airtimevalue = document.getElementById('airAmnt').value;
    		var recipent = document.getElementById('mobileno').value;
            var  min_airtime = "10";
    		if ((vendor != '--') && (airtimevalue != '') && (recipent != '') && (airtimevalue % 1 == 0) && (airtimevalue >= min_airtime)){
    			mybtn.disabled = false;
    		} else {
    			mybtn.disabled  = true;
    		}
    	}
    	
    	function confirmation(){
    	    document.getElementById('myForm').submit();
    	}

        $(document).ready(function(){
        	$("#mybtn").click(function(){
            	$('#modal22').modal('show');
        
        		document.getElementById('airtimevaluelbl').innerHTML = document.getElementById('airAmnt').value;
        		//recipent
        		document.getElementById('recipentlbl').innerHTML = document.getElementById('mobileno').value;
        		document.getElementById('networkVal').innerHTML = document.getElementById('networkName').value.toUpperCase();
        	});
        
        });
    	
    </script>
    
    
  <!-- Bootstrap core JavaScript-->
  <script src="./Airtime Topup_files/jquery.min.js.download"></script>
  <script src="./Airtime Topup_files/bootstrap.bundle.min.js.download"></script>

  <!-- Core plugin JavaScript-->
  <script src="./Airtime Topup_files/jquery.easing.min.js.download"></script>

  <!-- Custom scripts for all pages-->
  <script src="./Airtime Topup_files/sb-admin-2.min.js.download"></script>

  <script src="./Airtime Topup_files/jquery.dataTables.min.js.download"></script>
  <script src="./Airtime Topup_files/dataTables.bootstrap4.min.js.download"></script>

  <!-- Page level custom scripts -->
  <script src="./Airtime Topup_files/datatables-demo.js.download"></script>




</body></html>