<?php
require_once '../config/config.php'; 
  /*
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  */
  $page_title = "Rooms";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      
      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include_once 'top-nav.php'; ?>
        <!-- End of Topbar -->
        
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
        <section class="content-header">
          <h1>
            <?php echo $page_title; ?>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li class="active"><?php echo $page_title; ?></li>
          </ol>
        </section>
          <!-- Content Row -->
          <?php 
          if(isset($_GET["act"])){
            switch ($_GET["act"]) {
              case 'view':
                include_once 'inc/view_rooms.php';
                break;

              case 'add':
                include_once 'inc/add_room.php';
                break;

              case 'faulty':
                include_once 'inc/faulty_rooms.php';
                break;

              case 'view_rooms':
                include_once 'inc/view_block_rooms.php';
                break;

              default:
                # code...
                break;
            }
          }else{
            include_once 'inc/all_rooms.php';
          }

          ?>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      

<?php include_once 'foot.php'; ?>