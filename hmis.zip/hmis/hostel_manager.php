<?php require_once 'inc/head.php'; ?>
<?php
$username = "";
if(isset($_POST["ok-login"])){
  $username = mysqli_real_escape_string($conn,$_POST["username"]);
  $password = mysqli_real_escape_string($conn,$_POST["password"]);
  $sql = "SELECT * from hostel_managers where username = '$username' ";
  
  $result = $conn->query($sql)or
  die(mysqli_error($conn));
  if($result->num_rows > 0){

    $rs = $result->fetch_assoc();

    if(password_verify($password, $rs["password"])){
      $id = $rs['id'];
      $_SESSION['admin'] = $id;
      $_SESSION['admin_name'] = $rs['name'];
      $_SESSION['admin_role'] = $rs['role'];
      /*
      echo "<script>
              mscAlert({
                title: 'You have login successfully, click on OK to continue',
                okText: 'OK',
                dismissOverlay: true,

                onOk: function() {
                window.location.href='cpanel/index';
                },
              });
            </script>";
            */
      header("location: cpanel/index");
     }else{
      set_flash("Invalid username or password","danger");
     }
   }else{
    set_flash("Invalid username or password","danger");
   }
}
?>
<body class="hero">
    <section id="hero">
    <div class="hero-container">
      <div class="row">
          <div class="col-lg-12">
            <a href="default"><h2 class=""><span>Hostel</span> Management System</h2></a>
            <div class="w3l-login-form login">
                <h2>Hostel  Manager</h2>
                <?php flash(); ?>
                <form action="" method="POST">
                    <div class=" w3l-form-group">
                        <label>Username:</label>
                        <div class="group">
                            <i class="fas fa-user"></i>
                            <input type="text" class="form-control" name="username" placeholder="Username" required="required" value="<?php echo($username) ?>" />
                        </div>
                    </div>
                    <div class=" w3l-form-group">
                        <label>Password:</label>
                        <div class="group">
                            <i class="fas fa-unlock"></i>
                            <input type="password" class="form-control" name="password" placeholder="Password" required="required" />
                        </div>
                    </div>
                    <!--<div class="forgot">
                        <a href="#">Forgot Password?</a>
                        <p><input type="checkbox">Remember Me</p>
                    </div>-->
                    <button type="submit" name="ok-login">Login</button>
                </form>
                <p class=" w3l-register-p">Login as<a href="signin" class="register"> Student</a></p>
                <div class="alert alert-info">
                    <i class="fas fa-info"></i>
                    Contact administrator for help on Username and Password
                </div>
            </div>
            <?php require_once 'inc/foot-text.php'; ?>
          </div>
      </div>
    </div>
  </section>
<?php require_once 'inc/foot.php'; ?>
